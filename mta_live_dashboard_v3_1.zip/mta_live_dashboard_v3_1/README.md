# MTA Dashboard v3.1

Fixes parsing of Ubuntu sudo logs where a single sudo event spans multiple physical lines.

Run:

```bash
chmod +x upgrade.sh
./upgrade.sh
```

Then verify:

```bash
curl -s "http://127.0.0.1:8088/api/sudo?hours=4" | python3 -m json.tool
```

You should see commands such as `/usr/bin/id` and `/usr/sbin/ip a`.
