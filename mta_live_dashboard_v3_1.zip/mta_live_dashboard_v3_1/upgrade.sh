#!/usr/bin/env bash
set -euo pipefail

APP="/opt/mta-access-dashboard/app.py"
SERVICE="mta-access-dashboard"

[[ -f "$APP" ]] || { echo "ERROR: $APP not found"; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/opt/mta-access-dashboard-backup-$STAMP"

echo "Backing up dashboard..."
sudo cp -a /opt/mta-access-dashboard "$BACKUP"

echo "Applying multiline sudo parser patch..."

sudo python3 - "$APP" <<'PY'
from pathlib import Path
import sys

app_path = Path(sys.argv[1])
text = app_path.read_text()

start_marker = "# -----------------------------\n# Sudo parsing"
end_marker = "# -----------------------------\n# API"

start = text.find(start_marker)
end = text.find(end_marker, start)

if start == -1 or end == -1:
    raise SystemExit("Could not locate sudo parsing section in app.py")

patch = r"""# -----------------------------
# Sudo parsing
# -----------------------------
SUDO_START_RX = re.compile(r'^[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+:\s+')

def join_sudo_records(lines):
    records = []
    current = ""
    for line in lines:
        if SUDO_START_RX.match(line):
            if current:
                records.append(current.strip())
            current = line.strip()
        else:
            if current:
                current += " " + line.strip()
    if current:
        records.append(current.strip())
    return records

def parse_sudo_record(record, now):
    m = re.match(
        r'^(?P<mon>[A-Z][a-z]{2})\s+'
        r'(?P<day>\d{1,2})\s+'
        r'(?P<time>\d{2}:\d{2}:\d{2})\s+:\s+'
        r'(?P<user>[^:]+?)\s+:\s+'
        r'(?P<body>.*)$',
        record
    )
    if not m:
        return None

    body = m.group("body")

    def field(name):
        fm = re.search(
            rf'(?:^|;\s*){re.escape(name)}=(.*?)(?=\s*;\s*[A-Z]+(?:_[A-Z]+)?=|$)',
            body
        )
        return fm.group(1).strip() if fm else ""

    cm = re.search(r'(?:^|;\s*)COMMAND=(.*)$', body)

    try:
        dt = datetime.strptime(
            f'{now.year} {m.group("mon")} {m.group("day")} {m.group("time")}',
            "%Y %b %d %H:%M:%S"
        )
        if dt.timestamp() > now.timestamp() + 86400:
            dt = dt.replace(year=now.year - 1)
        iso = dt.astimezone().isoformat()
        ts = dt.timestamp()
    except Exception:
        iso = now.astimezone().isoformat()
        ts = now.timestamp()

    return {
        "timestamp": iso,
        "timestamp_epoch": ts,
        "username": m.group("user").strip(),
        "tty": field("TTY"),
        "pwd": field("PWD"),
        "run_as": field("USER"),
        "tsid": field("TSID"),
        "command": cm.group(1).strip() if cm else "",
        "raw": record
    }

def classify_sudo(command):
    c = command.lower()

    if any(x in c for x in [
        "rm -rf /var/spool/exim",
        "systemctl stop ssh",
        "systemctl disable ssh"
    ]):
        return "Critical"

    if any(x in c for x in [
        "iptables", "nft ", "nftables", "ufw ",
        "/etc/exim4", "/etc/ssh/",
        "useradd", "usermod", "passwd ",
        "visudo", "/etc/sudoers"
    ]):
        return "High"

    if any(x in c for x in [
        "systemctl restart", "systemctl reload",
        "apt install", "apt remove", "apt purge",
        "apt upgrade", "apt full-upgrade"
    ]):
        return "Medium"

    return "Normal"

def sudo_events(hours):
    path = Path("/var/log/sudo.log")
    if not path.exists():
        return []

    try:
        lines = path.read_text(errors="replace").splitlines()
    except Exception:
        return []

    now = datetime.now()
    cutoff = now.timestamp() - hours * 3600

    records = join_sudo_records(lines[-10000:])
    ev = []

    for record in records:
        e = parse_sudo_record(record, now)
        if not e:
            continue

        if e["timestamp_epoch"] < cutoff:
            continue

        e["risk"] = classify_sudo(e["command"])
        e.pop("timestamp_epoch", None)
        ev.append(e)

    ev.sort(key=lambda x: x["timestamp"], reverse=True)
    return ev

"""

app_path.write_text(text[:start] + patch + text[end:])
PY

echo "Restarting dashboard..."
sudo systemctl restart "$SERVICE"

echo "Waiting for sudo API..."
READY=0
for i in {1..15}; do
    if curl -fsS "http://127.0.0.1:8088/api/sudo?hours=4" >/tmp/mta-sudo.json 2>/dev/null; then
        READY=1
        echo "API ready after ${i}s."
        break
    fi
    sleep 1
done

if [[ "$READY" -ne 1 ]]; then
    echo "ERROR: sudo API did not become ready."
    sudo journalctl -u "$SERVICE" -n 100 --no-pager
    exit 1
fi

echo
echo "Current sudo API output:"
python3 -m json.tool </tmp/mta-sudo.json | head -120

echo
echo "Patch complete."
echo "Backup: $BACKUP"
