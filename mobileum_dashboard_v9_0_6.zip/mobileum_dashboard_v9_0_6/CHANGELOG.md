# V9.0.6 Change Log

## Fixed

- Fixed the V9.0.5 SQLite connection/file-descriptor leak. `db.connect()` is now a real context manager and always closes the SQLite connection in a `finally` block.
- Prevents the observed failure mode where dashboard/collector processes reached the 1024 soft FD limit, followed by `sqlite3.OperationalError: unable to open database file` and `/api/health` HTTP 500.
- Verification now performs an FD leak regression test after repeated `/api/health` calls.

## Mail Search / Message Trace

- Replaced the single search-type dropdown with separate Sender, Recipient, and Exim Message-ID inputs.
- Sender and Recipient can be entered together.
- Combined searches are correlated by Exim Message-ID: candidate messages are found by sender and retained only if the same message transaction contains the recipient.
- Current-queue combined searches intersect sender and recipient `exiqgrep` results.
- Exact Message-ID searches remain supported.
- V9.0.5 `kind=...&query=...` API calls remain supported for compatibility.

## Operations

- Installer preserves the existing `data/monitoring.db`.
- Installer creates a timestamped backup of the prior application code under `/opt/mobileum-mta-dashboard/backups/`.
- Added `/opt/mobileum-mta-dashboard/bin/check-dashboard-fds.sh` after install.
- FastAPI remains bound to `127.0.0.1:8089`; existing Nginx HTTPS access remains unchanged.
