# Mobileum MTA Dashboard v9.0.11

This version adds an aggregate delivery-event counter to the SMTP / Exim Overview.

## Overview delivery totals

The Overview shows:

```text
Delivered Totals — selected window                   4h

Total Delivery Events     Proofpoint Delivered     Barracuda Delivered
        20                        10                       10
Till date: 246
```

`Total Delivery Events` is the sum of successful delivery events on both downstream legs. If 10 messages are delivered to both Proofpoint and Barracuda, the total is 20 delivery events, not 10 unique messages.

The large value follows the selected dashboard Window. `Till date` covers all Exim mainlogs currently retained on the selected MTA. If old Exim logs are rotated/deleted, the retained-log till-date value is correspondingly bounded by that retention.

All earlier dashboard features are retained, including per-leg Delivered/Deferred/Failed, Run Now, persistent MTA selection, resource metrics, combined sender+recipient search, Message Trace, and the SQLite FD-leak fix.
