# Mobileum MTA Dashboard v9.0.11

## Total Delivery Events counter

- Adds **Total Delivery Events** to the Overview immediately below **Delivery Legs — last minute**.
- The large value follows the dashboard Window selector (1h / 4h / 12h / 24h / 48h / 7d).
- The same card also shows **Till date**, calculated across all Exim mainlog files currently retained on the selected MTA.
- Total Delivery Events is the sum of successful Proofpoint and Barracuda delivery-leg events.
- Therefore one message successfully delivered to both downstream systems counts as **two delivery events**.
- Proofpoint Delivered and Barracuda Delivered remain independent counters.

## Carried forward

- v9.0.10 selected-window Proofpoint/Barracuda totals.
- v9.0.9 persistent MTA selection and Run Now.
- v9.0.8 per-leg Delivered / Deferred / Failed counters.
- v9.0.7 CPU / RAM / Load / Network header metrics.
- v9.0.6 SQLite connection/file-descriptor leak fix and Sender + Recipient Mail Search correlation.
