# Mobileum MTA Monitoring Dashboard V9.0.2

V9 moves the V8 HTML dashboard to the Jumpbox and uses the existing SSH aliases `mta1` and `mta2` in the Jumpbox user's `~/.ssh/config`.

## Architecture

```text
MTA1 -- SSH read-only collection --\
                                  +--> Jumpbox collector --> SQLite --> FastAPI --> HTML dashboard
MTA2 -- SSH read-only collection --/
```

The browser never connects to an MTA directly. No full `/var/log` trees are copied to the Jumpbox.

## What is collected every 15 seconds

For each MTA the collector runs one bounded SSH session and records:

- SSH reachability
- Exim service state
- TCP/25 listening state
- active SMTP connections
- queue depth
- oldest queued message age
- frozen count
- accepted messages during the preceding minute
- completed messages during the preceding minute
- rejected events during the preceding minute
- deferred events during the preceding minute
- Proofpoint deliveries during the preceding minute
- Barracuda deliveries during the preceding minute
- TLS-tagged SMTP log events during the preceding minute
- panic-log events during the preceding minute
- Exim spool filesystem usage
- Exim spool inode usage

SQLite history is retained for 8 days by default.

## MTA health states

- **UP**: MTA reachable, Exim active, TCP/25 listening.
- **DEGRADED**: host reachable but Exim or SMTP listener is unhealthy.
- **UNREACHABLE**: SSH collection failed.
- **STALE**: collector has not written a new sample within 45 seconds. This avoids falsely claiming the MTA itself is down when the Jumpbox collector has stopped.

## Detailed sources queried only when required

| Dashboard area | Remote source |
|---|---|
| SSH Access / Failed Logins | `journalctl -u ssh` |
| Sudo Activity | `/var/log/sudo.log` |
| System Audit | `/var/log/audit/audit.log` |
| SMTP Connections | `ss` and recent `/var/log/exim4/mainlog` |
| Current Queue | `exim4 -bp` |
| Delivery | `/var/log/exim4/mainlog` |
| SMTP Security | `/var/log/exim4/rejectlog`, `/var/log/exim4/paniclog` |
| Message Trace | current and rotated Exim `mainlog` / `rejectlog` |

The dashboard never parses Exim spool files directly; it uses Exim commands for queue state.

## Tabs

Existing V8 OS/security tabs remain:

- SSH Access
- Failed Logins
- Sudo Activity
- System Audit

SMTP/Exim contains:

- Overview
- Connections
- Queue
- Delivery
- Security
- Message Trace

The first four trend graphs are:

1. SMTP connections
2. queue depth
3. accepted vs completed messages
4. Proofpoint vs Barracuda delivery

## Before installing

Run discovery from the Jumpbox as the same Unix user that currently runs `ssh mta1` and `ssh mta2`:

```bash
unzip mobileum_dashboard_v9.zip
cd mobileum_dashboard_v9
./bin/discover-mtas.sh | tee mta-source-discovery.txt
```

Confirm especially:

```text
ssh mta1
ssh mta2
sudo -n true on both remote MTAs
/var/log/exim4/mainlog
/var/log/exim4/rejectlog
/var/log/exim4/paniclog
/var/log/sudo.log
/var/log/audit/audit.log
```

If the actual Exim router names differ from these current values:

```text
proofpoint_copy
barracuda_production
```

edit `config.json` before installation.

## Install on the Jumpbox

Run the installer using `sudo` from the user whose `~/.ssh/config` contains the working MTA aliases:

```bash
sudo ./bin/install-jumpbox.sh
```

The installer deliberately runs both systemd services as `$SUDO_USER`, so the collector uses that user's existing `~/.ssh/config`, private key and known-host entries. The `.pem` path and MTA IP addresses are not copied into the dashboard configuration.

It creates:

```text
/opt/mobileum-mta-dashboard/
/etc/systemd/system/mobileum-mta-collector.service
/etc/systemd/system/mobileum-mta-dashboard.service
```

The dashboard listens only on:

```text
127.0.0.1:8089
```

## Verify

```bash
sudo ./bin/verify.sh
```

Or individually:

```bash
curl -s http://127.0.0.1:8089/api/health | python3 -m json.tool
curl -s 'http://127.0.0.1:8089/api/smtp/overview?mta=mta1&hours=4' | python3 -m json.tool
curl -s 'http://127.0.0.1:8089/api/smtp/overview?mta=mta2&hours=4' | python3 -m json.tool
```

## Publish through Nginx

An example reverse-proxy location is supplied at:

```text
nginx/mobileum-mta-dashboard.conf
```

It proxies `/mta-dashboard/` to `127.0.0.1:8089`. Use the Jumpbox's existing HTTPS/TLS configuration rather than exposing port 8089 publicly.

## Important note on dual-delivery integrity

The aggregate Delivery tab deliberately does **not** manufacture an `UNACCOUNTED` value from unrelated counters. Exact Proofpoint/Barracuda proof is determined from the same Exim Message-ID in **Message Trace**. Once we validate the final production Exim log format and router/transport names from MTA1/MTA2, the next correlation layer can persist per-message state centrally and safely calculate `UNACCOUNTED = 0` across the requested window.

## Security hardening after functional validation

V9 initially reuses the existing administrative SSH path because it is already working. After validation, replace it with a dedicated monitoring identity/restricted sudo wrapper so the dashboard service has only the specific read-only Exim/log commands it needs.


## V9.0.2 discovery hardening

V9.0.2 incorporates the first real MTA discovery results:

- health cards distinguish **host reachability** from Exim/SMTP state; a reachable host with Exim stopped remains **DEGRADED**, not **UNREACHABLE**.
- SMTP runtime shows the effective `local_interfaces`, `daemon_smtp_ports`, `smtp_accept_max`, `smtp_accept_max_per_host`, `queue_run_max`, systemd service state and unit enabled/masked state.
- Connections, Delivery and SMTP Security readers include current and rotated Exim logs (`.1` through `.10`, including `.gz`). This is required because an inactive MTA may have no current `mainlog` but still has useful history in `mainlog.1`.
- The collector still uses only the current Exim log for the preceding 60-second rate sample. Once Exim is active, this is the correct source for near-live counters.

The discovery showed both MTAs reachable while Exim was inactive/masked. This is a valid **host UP / SMTP DEGRADED** state and is intentionally displayed as such.
