# MTA Dashboard v4.1

Frontend rendering fix.

The backend/API was already returning sudo events correctly. v4.1 removes implicit browser element globals and uses explicit `document.getElementById()` references for all SSH, sudo, and audit render targets.

After upgrade, the header shows:
`Updated <time> · sudo events: <count>`

That count should match the `/api/sudo` event list and confirms the browser rendered the response.
