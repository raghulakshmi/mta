#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/mta-access-dashboard"
SERVICE="mta-access-dashboard"

[[ -d "$APP_DIR" ]] || { echo "ERROR: $APP_DIR not found."; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/opt/mta-access-dashboard-backup-$STAMP"

echo "Backing up current dashboard to $BACKUP"
sudo cp -a "$APP_DIR" "$BACKUP"

echo "Installing v4.1..."
sudo install -m 0644 app.py "$APP_DIR/app.py"
sudo install -m 0644 static/index.html "$APP_DIR/static/index.html"

echo "Restarting service..."
sudo systemctl restart "$SERVICE"

echo "Waiting for APIs..."
READY=0
for i in {1..15}; do
  if curl -fsS "http://127.0.0.1:8088/api/sudo?hours=4" >/tmp/mta-sudo.json 2>/dev/null; then
    READY=1
    echo "API ready after ${i}s."
    break
  fi
  sleep 1
done

if [[ "$READY" -ne 1 ]]; then
  echo "ERROR: API did not become ready."
  sudo journalctl -u "$SERVICE" -n 100 --no-pager
  exit 1
fi

echo
echo "Verifying new frontend renderer..."
grep -q "sudo events:" "$APP_DIR/static/index.html" && echo "Frontend v4.1 renderer installed." || {
  echo "ERROR: v4.1 frontend marker not found."
  exit 1
}

echo
echo "Sudo API currently reports:"
python3 - <<'PY'
import json
d=json.load(open('/tmp/mta-sudo.json'))
print("events:", len(d.get("events", [])))
for e in d.get("events", [])[:5]:
    print(e.get("timestamp"), e.get("command"))
PY

echo
echo "v4.1 upgrade complete."
echo "Backup: $BACKUP"
