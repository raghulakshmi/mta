from pathlib import Path
from datetime import datetime, timezone, timedelta
import sqlite3, json

BASE = Path(__file__).resolve().parent
DB_PATH = BASE / "data" / "monitoring.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS smtp_samples (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  mta TEXT NOT NULL,
  reachable INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  hostname TEXT,
  exim_service TEXT,
  listener INTEGER NOT NULL DEFAULT 0,
  active_connections INTEGER NOT NULL DEFAULT 0,
  connection_starts_1m INTEGER NOT NULL DEFAULT 0,
  unique_sources_1m INTEGER NOT NULL DEFAULT 0,
  connection_rejects_1m INTEGER NOT NULL DEFAULT 0,
  lost_connections_1m INTEGER NOT NULL DEFAULT 0,
  no_mail_1m INTEGER NOT NULL DEFAULT 0,
  incomplete_tx_1m INTEGER NOT NULL DEFAULT 0,
  protocol_errors_1m INTEGER NOT NULL DEFAULT 0,
  syntax_errors_1m INTEGER NOT NULL DEFAULT 0,
  relay_attempts_1m INTEGER NOT NULL DEFAULT 0,
  invalid_rcpt_1m INTEGER NOT NULL DEFAULT 0,
  tls_sessions_1m INTEGER NOT NULL DEFAULT 0,
  queue_depth INTEGER NOT NULL DEFAULT 0,
  oldest_queue_seconds INTEGER NOT NULL DEFAULT 0,
  frozen INTEGER NOT NULL DEFAULT 0,
  accepted_1m INTEGER NOT NULL DEFAULT 0,
  rejected_1m INTEGER NOT NULL DEFAULT 0,
  completed_1m INTEGER NOT NULL DEFAULT 0,
  deferred_1m INTEGER NOT NULL DEFAULT 0,
  proofpoint_1m INTEGER NOT NULL DEFAULT 0,
  barracuda_1m INTEGER NOT NULL DEFAULT 0,
  tls_in_1m INTEGER NOT NULL DEFAULT 0,
  panic_1m INTEGER NOT NULL DEFAULT 0,
  spool_used_pct REAL NOT NULL DEFAULT 0,
  spool_inode_pct REAL NOT NULL DEFAULT 0,
  error TEXT
);
CREATE INDEX IF NOT EXISTS idx_smtp_samples_mta_ts ON smtp_samples(mta, ts);

CREATE TABLE IF NOT EXISTS mta_state (
  mta TEXT PRIMARY KEY,
  last_attempt TEXT,
  last_seen TEXT,
  status TEXT,
  hostname TEXT,
  last_error TEXT
);
"""

def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB_PATH, timeout=10)
    c.row_factory = sqlite3.Row
    return c

EXTRA_SAMPLE_COLUMNS = {
    "connection_starts_1m": "INTEGER NOT NULL DEFAULT 0",
    "unique_sources_1m": "INTEGER NOT NULL DEFAULT 0",
    "connection_rejects_1m": "INTEGER NOT NULL DEFAULT 0",
    "lost_connections_1m": "INTEGER NOT NULL DEFAULT 0",
    "no_mail_1m": "INTEGER NOT NULL DEFAULT 0",
    "incomplete_tx_1m": "INTEGER NOT NULL DEFAULT 0",
    "protocol_errors_1m": "INTEGER NOT NULL DEFAULT 0",
    "syntax_errors_1m": "INTEGER NOT NULL DEFAULT 0",
    "relay_attempts_1m": "INTEGER NOT NULL DEFAULT 0",
    "invalid_rcpt_1m": "INTEGER NOT NULL DEFAULT 0",
    "tls_sessions_1m": "INTEGER NOT NULL DEFAULT 0",
}

def init_db():
    with connect() as c:
        c.executescript(SCHEMA)
        existing = {r[1] for r in c.execute("PRAGMA table_info(smtp_samples)")}
        for col, decl in EXTRA_SAMPLE_COLUMNS.items():
            if col not in existing:
                c.execute(f"ALTER TABLE smtp_samples ADD COLUMN {col} {decl}")

def insert_sample(s):
    init_db()
    keys = [
        "ts","mta","reachable","status","hostname","exim_service","listener",
        "active_connections","connection_starts_1m","unique_sources_1m",
        "connection_rejects_1m","lost_connections_1m","no_mail_1m","incomplete_tx_1m",
        "protocol_errors_1m","syntax_errors_1m","relay_attempts_1m","invalid_rcpt_1m",
        "tls_sessions_1m","queue_depth","oldest_queue_seconds","frozen",
        "accepted_1m","rejected_1m","completed_1m","deferred_1m",
        "proofpoint_1m","barracuda_1m","tls_in_1m","panic_1m",
        "spool_used_pct","spool_inode_pct","error"
    ]
    vals = [s.get(k) for k in keys]
    with connect() as c:
        c.execute(f"INSERT INTO smtp_samples ({','.join(keys)}) VALUES ({','.join('?' for _ in keys)})", vals)
        last_seen = s["ts"] if s.get("reachable") else None
        c.execute("""
        INSERT INTO mta_state(mta,last_attempt,last_seen,status,hostname,last_error)
        VALUES(?,?,?,?,?,?)
        ON CONFLICT(mta) DO UPDATE SET
          last_attempt=excluded.last_attempt,
          last_seen=COALESCE(excluded.last_seen,mta_state.last_seen),
          status=excluded.status,
          hostname=CASE WHEN excluded.hostname IS NOT NULL AND excluded.hostname!='' THEN excluded.hostname ELSE mta_state.hostname END,
          last_error=excluded.last_error
        """, (s["mta"], s["ts"], last_seen, s.get("status"), s.get("hostname",""), s.get("error","")))

def latest_sample(mta):
    init_db()
    with connect() as c:
        r = c.execute("SELECT * FROM smtp_samples WHERE mta=? ORDER BY ts DESC LIMIT 1", (mta,)).fetchone()
        return dict(r) if r else None

def states():
    init_db()
    with connect() as c:
        return [dict(r) for r in c.execute("SELECT * FROM mta_state ORDER BY mta")]

def trend(mta, hours=4, max_points=480):
    init_db()
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    with connect() as c:
        rows = [dict(r) for r in c.execute("SELECT * FROM smtp_samples WHERE mta=? AND ts>=? ORDER BY ts", (mta, cutoff))]
    if len(rows) <= max_points:
        return rows
    step = max(1, len(rows)//max_points)
    return rows[::step]

def purge(days=8):
    init_db()
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    with connect() as c:
        c.execute("DELETE FROM smtp_samples WHERE ts < ?", (cutoff,))
