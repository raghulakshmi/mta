# Mobileum MTA Monitoring Dashboard V9.0.5

V9.0.5 runs centrally on the Jumpbox and uses the existing SSH aliases `mta1` and `mta2`. No dashboard agent is installed on either MTA and raw log trees are not copied to the Jumpbox.

## V9.0.5 changes

- Replaces the old Message Trace-only page with **Mail Search / Message Trace**.
- Search by **recipient email** to list messages received for a Mobileum employee.
- Search by **sender email** to investigate whether mail from an external sender reached the MTA.
- Search by **Exim Message-ID** for a complete transaction trace.
- Results show received time, Exim ID, envelope sender, envelope recipient(s), source IP, size and current/final disposition.
- A **Trace** button on every result expands the complete Exim log history for that message.
- Displays **Rejected / Pre-Acceptance Matches** separately. This is important when a remote sender was rejected before a normal message trace existed.
- Classifies `frozen by ACL` as **SAFE-HOLD**, distinguishing our deliberate test hold from a production delivery problem.
- Removes the duplicate **SMTP Connections / selected window** and **Queue Depth / selected window** graphs from the SMTP Overview page. Their numeric counters remain. Detailed operational pages remain available.
- Upgrade installer now stops/restarts existing services, checks SQLite writability as the dashboard user, and preserves the existing SQLite history.

## Search sources

The search API queries the selected MTA on demand:

- `/var/log/exim4/mainlog`
- `/var/log/exim4/mainlog.1` ... rotations including `.gz`
- `/var/log/exim4/rejectlog`
- rotated reject logs including `.gz`
- current Exim queue via `exiqgrep` when available

The browser never SSHs to an MTA directly. FastAPI on the Jumpbox performs the bounded read-only SSH query.

## Important Exim logging for recipient investigations

For reliable historical searches by recipient, Exim must have these selectors in the active `log_selector`:

```text
+received_recipients
+received_sender
```

`received_recipients` causes the accepted envelope recipient list to be written on the `<=` receive line. This allows a later search such as `Venkatesh.AK@mobileum.com` even after the message has left the queue.

The existing telemetry selectors should remain; extend the existing `log_selector`, do not add a second `log_selector` directive.

Check MTA2 from the Jumpbox with:

```bash
./bin/check-mail-search-logging.sh mta2
```

## Upgrade on Jumpbox

```bash
cd ~/mta
unzip mobileum_dashboard_v9_0_5.zip
cd mobileum_dashboard_v9_0_5
sudo ./bin/install-jumpbox.sh
sudo ./bin/verify.sh
```

The installer preserves:

```text
/opt/mobileum-mta-dashboard/data/monitoring.db
```

and explicitly restarts:

```text
mobileum-mta-collector.service
mobileum-mta-dashboard.service
```

## Mail Search usage

Select the MTA and time window, then open:

```text
SMTP / Exim -> Mail Search / Trace
```

Examples:

```text
Recipient email: Venkatesh.AK@mobileum.com
Sender email:    sender@example.com
Message-ID:      1x8Gvu-00000000aXh-22l8
```

Recipient and sender searches return up to 200 matching message IDs for the selected window/current queue. Rejected events that do not have a normal message ID are shown separately.

## Architecture

```text
MTA1 -- bounded SSH reads --\
                             +--> Jumpbox FastAPI --> HTML dashboard
MTA2 -- bounded SSH reads --/
                 |
                 +--> 15-second aggregate collector --> SQLite history
```

## Existing dashboard areas

OS/security:

- SSH Access
- Failed Logins
- Sudo Activity
- System Audit

SMTP/Exim:

- Overview
- Connections
- Queue
- Delivery
- Security
- Mail Search / Trace

## Services

```bash
systemctl status mobileum-mta-collector --no-pager
systemctl status mobileum-mta-dashboard --no-pager
```

Dashboard listener:

```text
127.0.0.1:8089
```

Keep it private and reach it through the existing SSH tunnel.
