#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import subprocess, json, time, re, signal, sys
from db import insert_sample, init_db, purge

BASE = Path(__file__).resolve().parent
CFG = json.loads((BASE / "config.json").read_text())
MTAS = list(CFG["mtas"].keys())
INTERVAL = int(CFG.get("collector_interval_seconds",15))
PP = CFG.get("proofpoint_router","proofpoint_copy")
BA = CFG.get("barracuda_router","barracuda_production")
SSH_OPTS = ["-o","BatchMode=yes","-o","ConnectTimeout=4","-o","ServerAliveInterval=4","-o","ServerAliveCountMax=1"]
RUN=True

def stop(*_):
    global RUN
    RUN=False
signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)

def run_remote(mta, script, timeout=12):
    try:
        cp=subprocess.run(["ssh",*SSH_OPTS,mta,"sudo -n bash -s"], input=script, text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        if cp.returncode != 0:
            return "", (cp.stderr.strip() or f"ssh rc={cp.returncode}")[-400:]
        return cp.stdout, ""
    except Exception as e:
        return "", str(e)[:400]

def parse_age(s):
    m=re.fullmatch(r"(?:(\d+)d)?(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?",s or "")
    if not m: return 0
    d,h,mi,se=[int(x or 0) for x in m.groups()]
    return d*86400+h*3600+mi*60+se

def collect(mta):
    now=datetime.now(timezone.utc).isoformat()
    script=r'''set +e
EXIM=$(command -v exim4 || command -v exim)
MAIN=/var/log/exim4/mainlog
REJECT=/var/log/exim4/rejectlog
PANIC=/var/log/exim4/paniclog
SINCE=$(date -d '60 seconds ago' '+%Y-%m-%d %H:%M:%S' 2>/dev/null)
printf 'hostname=%s\n' "$(hostname -f 2>/dev/null || hostname)"
SAFE_UNIT=exim4-mobileum-safehold
SAFE_CFG=/etc/exim4/exim4.conf.mobileum-safehold
SAFE_STATE=$(systemctl is-active "$SAFE_UNIT" 2>/dev/null)
STD_STATE=$(systemctl is-active exim4 2>/dev/null)
if [ "$SAFE_STATE" = active ]; then
  SERVICE_STATE=active
  EXIM_CFG="-C $SAFE_CFG"
elif [ "$STD_STATE" = active ]; then
  SERVICE_STATE=active
  EXIM_CFG=""
else
  SERVICE_STATE=${SAFE_STATE:-$STD_STATE}
  [ -f "$SAFE_CFG" ] && EXIM_CFG="-C $SAFE_CFG" || EXIM_CFG=""
fi
printf 'service=%s\n' "${SERVICE_STATE:-inactive}"
printf 'listener=%s\n' "$(ss -ltnH 'sport = :25' 2>/dev/null | wc -l)"
printf 'connections=%s\n' "$(ss -Htn state established '( sport = :25 )' 2>/dev/null | wc -l)"
printf 'queue=%s\n' "$($EXIM $EXIM_CFG -bpc 2>/dev/null | tr -dc '0-9')"
Q="$($EXIM $EXIM_CFG -bp 2>/dev/null)"
printf 'frozen=%s\n' "$(printf '%s\n' "$Q" | grep -c '\*\*\* frozen \*\*\*')"
printf 'ages=%s\n' "$(printf '%s\n' "$Q" | awk '/^[[:space:]]*[0-9]+[smhd]/{print $1}' | tr '\n' ' ')"
if [ -r "$MAIN" ] && [ -n "$SINCE" ]; then
 awk -v s="$SINCE" 'substr($0,1,19)>=s && / <= /{c++} END{print "accepted=" c+0}' "$MAIN"
 awk -v s="$SINCE" 'substr($0,1,19)>=s && / Completed$/{c++} END{print "completed=" c+0}' "$MAIN"
 awk -v s="$SINCE" 'substr($0,1,19)>=s && / == /{c++} END{print "deferred=" c+0}' "$MAIN"
 awk -v s="$SINCE" 'substr($0,1,19)>=s && / => / && /R=__PP__/{c++} END{print "proofpoint=" c+0}' "$MAIN"
 awk -v s="$SINCE" 'substr($0,1,19)>=s && / => / && /R=__BA__/{c++} END{print "barracuda=" c+0}' "$MAIN"
 awk -v s="$SINCE" 'substr($0,1,19)>=s && /X=TLS/{c++} END{print "tls=" c+0}' "$MAIN"
else printf 'accepted=0\ncompleted=0\ndeferred=0\nproofpoint=0\nbarracuda=0\ntls=0\n'; fi
if [ -r "$REJECT" ] && [ -n "$SINCE" ]; then awk -v s="$SINCE" 'substr($0,1,19)>=s{c++} END{print "rejected=" c+0}' "$REJECT"; else echo rejected=0; fi
if [ -r "$PANIC" ] && [ -n "$SINCE" ]; then awk -v s="$SINCE" 'substr($0,1,19)>=s{c++} END{print "panic=" c+0}' "$PANIC"; else echo panic=0; fi
df -P /var/spool/exim4 2>/dev/null | awk 'NR==2{gsub("%","",$5); print "spool_used=" $5}'
df -Pi /var/spool/exim4 2>/dev/null | awk 'NR==2{gsub("%","",$5); print "spool_inode=" $5}'
'''.replace('__PP__',PP).replace('__BA__',BA)
    out,err=run_remote(mta,script)
    if not out:
        return {"ts":now,"mta":mta,"reachable":0,"status":"UNREACHABLE","hostname":"","exim_service":"unknown","listener":0,
                "active_connections":0,"queue_depth":0,"oldest_queue_seconds":0,"frozen":0,"accepted_1m":0,"rejected_1m":0,
                "completed_1m":0,"deferred_1m":0,"proofpoint_1m":0,"barracuda_1m":0,"tls_in_1m":0,"panic_1m":0,
                "spool_used_pct":0,"spool_inode_pct":0,"error":err or "no response"}
    d={}
    for line in out.splitlines():
        if "=" in line:
            k,v=line.split("=",1); d[k.strip()]=v.strip()
    def ni(k):
        try:return int(float(d.get(k,0) or 0))
        except:return 0
    service=d.get("service","unknown")
    listener=ni("listener")>0
    status="UP" if service=="active" and listener else "DEGRADED"
    return {"ts":now,"mta":mta,"reachable":1,"status":status,"hostname":d.get("hostname",""),"exim_service":service,"listener":1 if listener else 0,
            "active_connections":ni("connections"),"queue_depth":ni("queue"),"oldest_queue_seconds":max([parse_age(x) for x in d.get("ages","").split()] or [0]),"frozen":ni("frozen"),
            "accepted_1m":ni("accepted"),"rejected_1m":ni("rejected"),"completed_1m":ni("completed"),"deferred_1m":ni("deferred"),
            "proofpoint_1m":ni("proofpoint"),"barracuda_1m":ni("barracuda"),"tls_in_1m":ni("tls"),"panic_1m":ni("panic"),
            "spool_used_pct":ni("spool_used"),"spool_inode_pct":ni("spool_inode"),"error":err}

def main():
    init_db(); n=0
    while RUN:
        start=time.monotonic()
        for mta in MTAS:
            try: insert_sample(collect(mta))
            except Exception as e: print(f"collector error {mta}: {e}", file=sys.stderr, flush=True)
        n+=1
        if n%240==0: purge(8)
        time.sleep(max(1, INTERVAL-(time.monotonic()-start)))

if __name__=="__main__": main()
