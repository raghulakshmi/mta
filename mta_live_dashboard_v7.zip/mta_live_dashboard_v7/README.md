# MTA Dashboard v7 — System Audit

v7 expands the old Exim-only Audit tab into a complete **System Audit** view.

## Audit families

- Exim
- SSH
- Privilege
- Identity
- Service
- Network
- Firewall
- Audit Security

The backend reads `/var/log/audit/audit.log` and accepts the focused audit keys configured in `mta-audit.rules`.

## Dashboard filters

The System Audit tab provides:

`All | Exim | SSH | Privilege | Identity | Service | Network | Firewall | Audit Security`

## Upgrade

```bash
chmod +x upgrade.sh
./upgrade.sh
```

Then refresh the browser.

## Test examples

```bash
sudo touch /etc/exim4/audit-test
sudo rm /etc/exim4/audit-test

sudo systemctl restart exim4

sudo touch /etc/ssh/audit-test
sudo rm /etc/ssh/audit-test

sudo touch /etc/audit/audit-test
sudo rm /etc/audit/audit-test

sudo ip addr show
sudo nft list ruleset
```

Those should appear under the corresponding System Audit filter once the matching audit rules are loaded.
