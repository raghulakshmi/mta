#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/mta-access-dashboard"
SERVICE="mta-access-dashboard"

[[ -d "$APP_DIR" ]] || { echo "ERROR: $APP_DIR not found"; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/opt/mta-access-dashboard-backup-$STAMP"

echo "Backing up current dashboard to $BACKUP"
sudo cp -a "$APP_DIR" "$BACKUP"

echo "Installing v7..."
sudo install -m 0644 app.py "$APP_DIR/app.py"
sudo install -m 0644 static/index.html "$APP_DIR/static/index.html"

echo "Restarting service..."
sudo systemctl restart "$SERVICE"

echo "Waiting for APIs..."
READY=0
for i in {1..15}; do
  if curl -fsS "http://127.0.0.1:8088/api/audit?hours=4" >/tmp/mta-v7-audit.json 2>/dev/null; then
    READY=1
    echo "Audit API ready after ${i}s."
    break
  fi
  sleep 1
done

if [[ "$READY" -ne 1 ]]; then
  echo "ERROR: dashboard API did not become ready"
  sudo journalctl -u "$SERVICE" -n 100 --no-pager
  exit 1
fi

echo
echo "Audit API event summary:"
python3 - <<'PY'
import json, collections
d=json.load(open('/tmp/mta-v7-audit.json'))
ev=d.get("events",[])
print("events:",len(ev))
c=collections.Counter(e.get("family","Other") for e in ev)
for k,v in sorted(c.items()):
    print(f"{k}: {v}")
print()
for e in ev[:10]:
    print(e.get("timestamp"), e.get("family"), e.get("category"), e.get("command"))
PY

echo
echo "Checking frontend markers..."
grep -q "Audit Security" "$APP_DIR/static/index.html"
grep -q "auditFamilyFilter" "$APP_DIR/static/index.html"
echo "v7 frontend installed."

echo
echo "v7 upgrade complete."
echo "Backup: $BACKUP"
