
from fastapi import FastAPI, Query
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from datetime import datetime, timezone, timedelta
from collections import defaultdict
import subprocess, re, pwd, binascii, shlex, os
from functools import lru_cache
import json
from db import latest_sample, states as db_states, trend as db_trend, init_db

app = FastAPI(title="Mobileum MTA Monitoring Dashboard v9.0.6")
BASE = Path(__file__).resolve().parent

ALLOWED_MTAS = {"mta1", "mta2"}
SSH_OPTS = ["-o", "BatchMode=yes", "-o", "ConnectTimeout=5", "-o", "ServerAliveInterval=5", "-o", "ServerAliveCountMax=1"]

def validate_mta(mta):
    if mta not in ALLOWED_MTAS:
        raise ValueError(f"Unsupported MTA: {mta}")
    return mta

def ssh_run(mta, remote_command, timeout=20, stdin_text=None):
    validate_mta(mta)
    try:
        cp = subprocess.run(
            ["ssh", *SSH_OPTS, mta, remote_command],
            input=stdin_text, text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            timeout=timeout, check=False
        )
        return cp.stdout if cp.returncode == 0 else ""
    except Exception:
        return ""

@lru_cache(maxsize=128)
def remote_uid_name(mta, uid):
    if str(uid) in ("", "4294967295"):
        return str(uid)
    out = ssh_run(mta, f"getent passwd {shlex.quote(str(uid))} | cut -d: -f1", timeout=8).strip()
    return out or str(uid)

app.mount("/static", StaticFiles(directory=BASE/"static"), name="static")

def run(cmd):
    try:
        return subprocess.check_output(cmd, text=True, stderr=subprocess.DEVNULL)
    except Exception:
        return ""

def uid_name(uid):
    try:
        return pwd.getpwuid(int(uid)).pw_name
    except Exception:
        return str(uid)

def parse_iso_ts(line):
    token = line.split(" ",1)[0] if line else ""
    try:
        return datetime.fromisoformat(token.replace("Z","+00:00")).isoformat()
    except Exception:
        return datetime.now(timezone.utc).isoformat()

# -----------------------------
# SSH
# -----------------------------
RX_CONN=re.compile(r"Connection from (?P<src_ip>\S+) port (?P<src_port>\d+) on (?P<dst_ip>\S+) port (?P<dst_port>\d+)")
RX_KEY=re.compile(r"Accepted key (?P<key_type>\S+) (?P<fingerprint>SHA256:\S+) found at (?P<auth_file>\S+):(?P<auth_line>\d+)")
RX_OK=re.compile(r"Accepted (?P<method>\S+) for (?P<user>\S+) from (?P<src_ip>\S+) port (?P<src_port>\d+) ssh2(?:: (?P<key_type>\S+) (?P<fingerprint>SHA256:\S+))?")
RX_FAIL=re.compile(r"Failed (?P<method>\S+) for (?:invalid user )?(?P<user>\S+) from (?P<src_ip>\S+) port (?P<src_port>\d+)")
RX_INVALID=re.compile(r"Invalid user (?P<user>\S+) from (?P<src_ip>\S+)")
RX_OPEN=re.compile(r"session opened for user (?P<user>\S+)\(uid=(?P<uid>\d+)\)")
RX_CHILD=re.compile(r"User child is on pid (?P<pid>\d+)")
RX_KEX=re.compile(r"kex_exchange_identification: Connection closed by remote host")

def blank_ssh(t):
    return dict(timestamp=t,event_stage="",username="",source_ip="",source_port="",
                destination_ip="",destination_port="",result="",method="",key_type="",
                key_fingerprint="",authorized_keys_file="",authorized_keys_line="",
                sshd_pid="",session_pid="",risk="Normal",raw="")

def ssh_events(hours, mta):
    out=ssh_run(mta, f"sudo -n journalctl -u ssh --since {shlex.quote(str(hours) + ' hours ago')} --no-pager -o short-iso", timeout=20)
    pending={}; ev=[]
    for line in out.splitlines():
        t=parse_iso_ts(line)
        pm=re.search(r"sshd\[(\d+)\]",line); pid=pm.group(1) if pm else ""
        c=pending.setdefault(pid,blank_ssh(t)); c["sshd_pid"]=pid
        m=RX_CONN.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Connection",source_ip=d["src_ip"],source_port=d["src_port"],
                destination_ip=d["dst_ip"],destination_port=d["dst_port"],result="CONNECTED",raw=line); ev.append(dict(c)); continue
        m=RX_KEY.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Key accepted",key_type=d["key_type"],key_fingerprint=d["fingerprint"],
                authorized_keys_file=d["auth_file"],authorized_keys_line=d["auth_line"],result="KEY_ACCEPTED",raw=line); ev.append(dict(c)); continue
        m=RX_OK.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Authentication success",username=d["user"],source_ip=d["src_ip"],
                source_port=d["src_port"],result="SUCCESS",method=d["method"],key_type=d.get("key_type") or c["key_type"],
                key_fingerprint=d.get("fingerprint") or c["key_fingerprint"],raw=line); ev.append(dict(c)); continue
        m=RX_FAIL.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Authentication failure",username=d["user"],source_ip=d["src_ip"],
                source_port=d["src_port"],result="FAILED",method=d["method"],risk="Medium",raw=line); ev.append(dict(c)); continue
        m=RX_INVALID.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Invalid user",username=d["user"],source_ip=d["src_ip"],
                result="FAILED",risk="High",raw=line); ev.append(dict(c)); continue
        m=RX_OPEN.search(line)
        if m:
            c.update(timestamp=t,event_stage="Session opened",username=m["user"],result="SESSION_OPEN",raw=line); ev.append(dict(c)); continue
        m=RX_CHILD.search(line)
        if m:
            c.update(timestamp=t,event_stage="Session child",session_pid=m["pid"],result="SESSION_ACTIVE",raw=line); ev.append(dict(c)); continue
        if RX_KEX.search(line):
            c.update(timestamp=t,event_stage="Handshake failure",result="PREAUTH_DISCONNECT",risk="Medium",raw=line); ev.append(dict(c)); continue

    fails=defaultdict(int)
    for e in ev:
        if e["result"]=="FAILED" and e["source_ip"]:
            fails[e["source_ip"]]+=1
    for e in ev:
        ip=e["source_ip"]
        if e["result"]=="FAILED" and ip and fails[ip]>=10: e["risk"]="High"
        if e["result"]=="SUCCESS" and ip and fails[ip]>=5: e["risk"]="Critical"
    ev.sort(key=lambda x:x["timestamp"],reverse=True)
    return ev

def current_sessions(mta):
    s=[]
    for line in ssh_run(mta, "who", timeout=8).splitlines():
        m=re.match(r"(?P<user>\S+)\s+(?P<tty>\S+)\s+(?P<date>\S+)\s+(?P<time>\S+)\s+\((?P<ip>[^)]+)\)",line)
        if m: s.append(m.groupdict())
    return s

# -----------------------------
# Sudo - multiline Ubuntu format
# -----------------------------
SUDO_START_RX = re.compile(r'^[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+:\s+')

def join_sudo_records(lines):
    records=[]; current=""
    for line in lines:
        if SUDO_START_RX.match(line):
            if current: records.append(current.strip())
            current=line.strip()
        elif current:
            current += " " + line.strip()
    if current: records.append(current.strip())
    return records

def parse_sudo_record(record, now):
    m=re.match(r'^(?P<mon>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+(?P<time>\d{2}:\d{2}:\d{2})\s+:\s+(?P<user>[^:]+?)\s+:\s+(?P<body>.*)$',record)
    if not m: return None
    body=m.group("body")
    def field(name):
        fm=re.search(rf'(?:^|;\s*){re.escape(name)}=(.*?)(?=\s*;\s*[A-Z]+(?:_[A-Z]+)?=|$)',body)
        return fm.group(1).strip() if fm else ""
    cm=re.search(r'(?:^|;\s*)COMMAND=(.*)$',body)
    try:
        dt=datetime.strptime(f'{now.year} {m.group("mon")} {m.group("day")} {m.group("time")}',"%Y %b %d %H:%M:%S")
        if dt.timestamp()>now.timestamp()+86400: dt=dt.replace(year=now.year-1)
    except Exception:
        dt=now
    return {"timestamp":dt.astimezone().isoformat(),"timestamp_epoch":dt.timestamp(),
            "username":m.group("user").strip(),"tty":field("TTY"),"pwd":field("PWD"),
            "run_as":field("USER"),"tsid":field("TSID"),"command":cm.group(1).strip() if cm else "",
            "raw":record}

def classify_sudo(command):
    c=command.lower()
    if any(x in c for x in ["rm -rf /var/spool/exim","systemctl stop ssh","systemctl disable ssh"]): return "Critical"
    if any(x in c for x in ["iptables","nft ","nftables","ufw ","/etc/exim4","/etc/ssh/","useradd","usermod","passwd ","visudo","/etc/sudoers"]): return "High"
    if any(x in c for x in ["systemctl restart","systemctl reload","apt install","apt remove","apt purge","apt upgrade","apt full-upgrade"]): return "Medium"
    return "Normal"

def sudo_events(hours, mta):
    raw = ssh_run(mta, "sudo -n tail -n 10000 /var/log/sudo.log 2>/dev/null", timeout=20)
    if not raw: return []
    lines=raw.splitlines()
    now=datetime.now(); cutoff=now.timestamp()-hours*3600
    ev=[]
    for record in join_sudo_records(lines[-10000:]):
        e=parse_sudo_record(record,now)
        if not e or e["timestamp_epoch"]<cutoff: continue
        e["risk"]=classify_sudo(e["command"]); e.pop("timestamp_epoch",None); ev.append(e)
    ev.sort(key=lambda x:x["timestamp"],reverse=True)
    return ev

# -----------------------------
# Auditd - Exim config changes
# -----------------------------
AUDIT_ID_RX = re.compile(r'msg=audit\((?P<epoch>\d+(?:\.\d+)?):(?P<serial>\d+)\)')
KV_RX = re.compile(r'(\w+)=("[^"]*"|\S+)')

def kv(line):
    out={}
    for k,v in KV_RX.findall(line):
        if len(v)>=2 and v[0]=='"' and v[-1]=='"':
            v=v[1:-1]
        out[k]=v
    return out

def decode_proctitle(value):
    if not value: return ""
    try:
        b=binascii.unhexlify(value)
        return " ".join(x.decode(errors="replace") for x in b.split(b"\x00") if x)
    except Exception:
        return value

def audit_exim_events(hours, mta):
    raw = ssh_run(mta, "sudo -n tail -n 30000 /var/log/audit/audit.log 2>/dev/null", timeout=25)
    if not raw: return []
    lines=raw.splitlines()

    cutoff=datetime.now().timestamp()-hours*3600
    grouped=defaultdict(list)

    for line in lines[-30000:]:
        m=AUDIT_ID_RX.search(line)
        if m:
            grouped[(m.group("epoch"),m.group("serial"))].append(line)

    events=[]
    for (epoch,serial), rows in grouped.items():
        if float(epoch)<cutoff: continue

        # Require a real syscall carrying one of the focused MTA audit keys.
        supported_keys = {
            "exim_config", "exim_service", "exim_systemd", "exim_maps",
            "exim_scripts", "exim_custom", "exim_tls_cert", "exim_tls_key",
            "ssh_config",
            "privilege_config", "privilege_change",
            "identity", "identity_change",
            "systemd_config", "service_change",
            "network_config", "network_change",
            "firewall_config", "firewall_change",
            "audit_config"
        }
        syscall_line = None
        category = None
        for r in rows:
            if not r.startswith("type=SYSCALL"):
                continue
            km = re.search(r'key="(?P<key>[^"]+)"', r)
            if km and km.group("key") in supported_keys:
                syscall_line = r
                category = km.group("key")
                break
        if not syscall_line:
            continue

        sk=kv(syscall_line)
        paths=[]
        action="CHANGE"
        for r in rows:
            if r.startswith("type=PATH"):
                p=kv(r)
                name=p.get("name","")
                nt=p.get("nametype","")
                # Ignore parent directory entry when a child path is available
                if name:
                    paths.append((name,nt))
                    if nt=="CREATE": action="CREATE"
                    elif nt=="DELETE": action="DELETE"

        chosen=""
        for name,nt in paths:
            if nt not in ("PARENT",):
                chosen=name
                break
        if not chosen and paths:
            chosen=paths[0][0]

        cwd_line=next((r for r in rows if r.startswith("type=CWD")), "")
        cwd=kv(cwd_line).get("cwd","") if cwd_line else ""

        pt_line=next((r for r in rows if r.startswith("type=PROCTITLE")), "")
        pt=kv(pt_line).get("proctitle","") if pt_line else ""
        command=decode_proctitle(pt)

        auid=sk.get("auid","")
        uid=sk.get("uid","")
        euid=sk.get("euid","")
        success=sk.get("success","")
        comm=sk.get("comm","")
        exe=sk.get("exe","")
        tty=sk.get("tty","")
        ses=sk.get("ses","")
        event_time=datetime.fromtimestamp(float(epoch)).astimezone().isoformat()

        family = (
            "Exim" if category.startswith("exim_") else
            "SSH" if category == "ssh_config" else
            "Privilege" if category.startswith("privilege_") else
            "Identity" if category.startswith("identity") else
            "Service" if category in {"systemd_config","service_change"} else
            "Network" if category.startswith("network_") else
            "Firewall" if category.startswith("firewall_") else
            "Audit Security" if category == "audit_config" else
            "Other"
        )

        risk = (
            "Critical" if category == "audit_config" else
            "High" if category in {
                "privilege_config","privilege_change","identity","identity_change",
                "firewall_config","firewall_change","ssh_config"
            } else
            "Medium" if category in {
                "service_change","systemd_config","network_config","network_change"
            } or category.startswith("exim_") else
            "Low"
        )

        events.append({
            "timestamp":event_time,
            "event_id":serial,
            "original_user":remote_uid_name(mta, auid) if auid not in ("","4294967295") else auid,
            "auid":auid,
            "run_as_user":remote_uid_name(mta, euid or uid) if (euid or uid) else "",
            "uid":uid,
            "euid":euid,
            "tty":tty,
            "session":ses,
            "path":chosen,
            "action":action,
            "command":command or comm,
            "comm":comm,
            "exe":exe,
            "cwd":cwd,
            "result":"SUCCESS" if success=="yes" else "FAILED",
            "category":category,
            "family":family,
            "risk":risk,
            "raw":"\n".join(rows)
        })

    events.sort(key=lambda x:x["timestamp"],reverse=True)
    return events

# -----------------------------
# API
# -----------------------------
@app.get("/",response_class=HTMLResponse)
def index():
    return (BASE/"static/index.html").read_text(encoding="utf-8")

@app.get("/api/summary")
def summary(hours:int=Query(24,ge=1,le=720), mta:str=Query("mta1")):
    validate_mta(mta)
    ev=ssh_events(hours,mta); ses=current_sessions(mta)
    auth=[e for e in ev if e["event_stage"] in ("Authentication success","Authentication failure","Invalid user")]
    byip=defaultdict(lambda:{"attempts":0,"success":0,"failures":0,"users":set()})
    byuser=defaultdict(lambda:{"success":0,"failures":0,"ips":set(),"last_seen":None})
    for e in auth:
        ip,u=e["source_ip"],e["username"]
        if ip:
            byip[ip]["attempts"]+=1; byip[ip]["success"]+=e["result"]=="SUCCESS"; byip[ip]["failures"]+=e["result"]=="FAILED"
            if u: byip[ip]["users"].add(u)
        if u:
            byuser[u]["success"]+=e["result"]=="SUCCESS"; byuser[u]["failures"]+=e["result"]=="FAILED"
            if ip: byuser[u]["ips"].add(ip)
            if not byuser[u]["last_seen"] or e["timestamp"]>byuser[u]["last_seen"]: byuser[u]["last_seen"]=e["timestamp"]
    return {"hours":hours,
      "kpis":{"active_sessions":len(ses),"successful_logins":sum(e["event_stage"]=="Authentication success" for e in ev),
              "failed_logins":sum(e["event_stage"]=="Authentication failure" for e in ev),"invalid_users":sum(e["event_stage"]=="Invalid user" for e in ev),
              "handshake_failures":sum(e["event_stage"]=="Handshake failure" for e in ev),
              "unique_source_ips":len({e["source_ip"] for e in ev if e["source_ip"]}),"critical_alerts":sum(e["risk"]=="Critical" for e in ev)},
      "events":ev[:300],"alerts":[e for e in ev if e["risk"] in ("High","Critical")][:25],
      "top_ips":[{"ip":ip,"attempts":v["attempts"],"success":v["success"],"failures":v["failures"],"users":sorted(v["users"])}
                 for ip,v in sorted(byip.items(),key=lambda x:x[1]["attempts"],reverse=True)][:20],
      "users":[{"user":u,"success":v["success"],"failures":v["failures"],"unique_ips":len(v["ips"]),"last_seen":v["last_seen"]} for u,v in byuser.items()],
      "sessions":ses}

@app.get("/api/sudo")
def sudo_api(hours:int=Query(24,ge=1,le=720), mta:str=Query("mta1")):
    validate_mta(mta)
    ev=sudo_events(hours,mta); byuser=defaultdict(int)
    for e in ev: byuser[e["username"]]+=1
    return {"hours":hours,
      "kpis":{"sudo_commands":len(ev),"unique_sudo_users":len(byuser),"run_as_root":sum(e["run_as"]=="root" for e in ev),
              "high_risk_commands":sum(e["risk"] in ("High","Critical") for e in ev)},
      "events":ev[:500],"top_users":[{"user":u,"commands":c} for u,c in sorted(byuser.items(),key=lambda x:x[1],reverse=True)]}

@app.get("/api/audit")
def audit_api(hours:int=Query(24,ge=1,le=720), mta:str=Query("mta1")):
    validate_mta(mta)
    ev=audit_exim_events(hours,mta)
    users=defaultdict(int); actions=defaultdict(int)
    for e in ev:
        users[e["original_user"]]+=1; actions[e["action"]]+=1
    return {"hours":hours,
      "kpis":{"audit_events":len(ev),"unique_change_users":len(users),"successful_changes":sum(e["result"]=="SUCCESS" for e in ev),
              "failed_changes":sum(e["result"]=="FAILED" for e in ev)},
      "events":ev[:500],
      "top_users":[{"user":u,"changes":c} for u,c in sorted(users.items(),key=lambda x:x[1],reverse=True)],
      "actions":[{"action":a,"count":c} for a,c in sorted(actions.items(),key=lambda x:x[1],reverse=True)]}

# -----------------------------
# SMTP / Exim central monitoring - V9
# -----------------------------
CFG = json.loads((BASE / "config.json").read_text())
STALE_AFTER = int(CFG.get("stale_after_seconds",45))
PP_ROUTER = CFG.get("proofpoint_router","proofpoint_copy")
BA_ROUTER = CFG.get("barracuda_router","barracuda_production")
init_db()

def _iso_age_seconds(ts):
    if not ts:
        return None
    try:
        d=datetime.fromisoformat(ts.replace("Z","+00:00"))
        if d.tzinfo is None:
            d=d.replace(tzinfo=timezone.utc)
        return max(0,int((datetime.now(timezone.utc)-d.astimezone(timezone.utc)).total_seconds()))
    except Exception:
        return None

def _state_payload(mta):
    rows={r["mta"]:r for r in db_states()}
    r=rows.get(mta,{"mta":mta,"last_attempt":None,"last_seen":None,"status":"NO DATA","hostname":"","last_error":""})
    age=_iso_age_seconds(r.get("last_attempt"))
    display=r.get("status") or "NO DATA"
    if age is None or age > STALE_AFTER:
        display="STALE" if r.get("last_attempt") else "NO DATA"
    latest=latest_sample(mta) or {}
    return {**r,"display_status":display,"sample_age_seconds":age,
            "host_reachable":bool(latest.get("reachable",0)),
            "exim_service":latest.get("exim_service","unknown"),
            "listener":int(latest.get("listener",0) or 0),
            "active_connections":int(latest.get("active_connections",0) or 0),
            "queue_depth":int(latest.get("queue_depth",0) or 0),
            "frozen":int(latest.get("frozen",0) or 0),
            "cpu_used_pct":float(latest.get("cpu_used_pct",0) or 0),
            "mem_used_pct":float(latest.get("mem_used_pct",0) or 0),
            "load1":float(latest.get("load1",0) or 0),
            "net_iface":latest.get("net_iface","") or "",
            "net_rx_mbps":float(latest.get("net_rx_mbps",0) or 0),
            "net_tx_mbps":float(latest.get("net_tx_mbps",0) or 0)}

@app.get("/api/health")
def all_health():
    return {"mtas":[_state_payload(m) for m in sorted(ALLOWED_MTAS)],"stale_after_seconds":STALE_AFTER}

@app.get("/api/health/remote")
def remote_health(mta:str=Query("mta1")):
    validate_mta(mta)
    return _state_payload(mta)

@app.get("/api/smtp/overview")
def smtp_overview(hours:int=Query(4,ge=1,le=168), mta:str=Query("mta1")):
    validate_mta(mta)
    return {"mta":mta,"hours":hours,"state":_state_payload(mta),"latest":latest_sample(mta) or {}}

@app.get("/api/smtp/trend")
def smtp_trend(hours:int=Query(4,ge=1,le=168), mta:str=Query("mta1")):
    validate_mta(mta)
    return {"mta":mta,"hours":hours,"samples":db_trend(mta,hours)}

def _remote_text(mta, script, timeout=20):
    return ssh_run(mta,"sudo -n bash -s",timeout=timeout,stdin_text=script)

@app.get("/api/smtp/runtime")
def smtp_runtime(mta:str=Query("mta1")):
    validate_mta(mta)
    script=r'''set +e
EXIM=$(command -v exim4 || command -v exim)
SAFE_UNIT=exim4-mobileum-safehold
SAFE_CFG=/etc/exim4/exim4.conf.mobileum-safehold
SAFE_STATE=$(systemctl is-active "$SAFE_UNIT" 2>/dev/null)
STD_STATE=$(systemctl is-active exim4 2>/dev/null)
if [ "$SAFE_STATE" = active ]; then
  ACTIVE_UNIT=$SAFE_UNIT
  EXIM_CFG="-C $SAFE_CFG"
elif [ "$STD_STATE" = active ]; then
  ACTIVE_UNIT=exim4
  EXIM_CFG=""
elif [ -f "$SAFE_CFG" ]; then
  ACTIVE_UNIT=$SAFE_UNIT
  EXIM_CFG="-C $SAFE_CFG"
else
  ACTIVE_UNIT=exim4
  EXIM_CFG=""
fi
printf 'hostname=%s\n' "$(hostname -f 2>/dev/null || hostname)"
printf 'version=%s\n' "$($EXIM $EXIM_CFG -bV 2>/dev/null | head -1)"
printf 'primary_hostname=%s\n' "$($EXIM $EXIM_CFG -bP primary_hostname 2>/dev/null | sed 's/^[^=]*= *//')"
printf 'spool=%s\n' "$($EXIM $EXIM_CFG -bP spool_directory 2>/dev/null | sed 's/^[^=]*= *//')"
printf 'interfaces=%s\n' "$($EXIM $EXIM_CFG -bP local_interfaces 2>/dev/null | sed 's/^[^=]*= *//')"
printf 'daemon_smtp_ports=%s\n' "$($EXIM $EXIM_CFG -bP daemon_smtp_ports 2>/dev/null | sed 's/^[^=]*= *//')"
printf 'smtp_accept_max=%s\n' "$($EXIM $EXIM_CFG -bP smtp_accept_max 2>/dev/null | sed 's/^[^=]*= *//')"
printf 'smtp_accept_max_per_host=%s\n' "$($EXIM $EXIM_CFG -bP smtp_accept_max_per_host 2>/dev/null | sed 's/^[^=]*= *//')"
printf 'queue_run_max=%s\n' "$($EXIM $EXIM_CFG -bP queue_run_max 2>/dev/null | sed 's/^[^=]*= *//')"
printf 'log_selector=%s\n' "$($EXIM $EXIM_CFG -bP log_selector 2>/dev/null | sed 's/^[^=]*= *//')"
printf 'service_name=%s\n' "$ACTIVE_UNIT"
printf 'unit_enabled=%s\n' "$(systemctl is-enabled "$ACTIVE_UNIT" 2>/dev/null)"
printf 'service_state=%s\n' "$(systemctl is-active "$ACTIVE_UNIT" 2>/dev/null)"
printf 'service_active_since=%s\n' "$(systemctl show "$ACTIVE_UNIT" -p ActiveEnterTimestamp --value 2>/dev/null)"
printf 'normal_exim_state=%s\n' "$STD_STATE"
printf 'safehold_exim_state=%s\n' "$SAFE_STATE"
echo '__EXIWHAT__'
(command -v exiwhat >/dev/null && exiwhat 2>/dev/null) || true
'''
    out=_remote_text(mta,script,15)
    data={}; exi=[]; inex=False
    for line in out.splitlines():
        if line=='__EXIWHAT__':
            inex=True; continue
        if inex:
            exi.append(line); continue
        if '=' in line:
            k,v=line.split('=',1); data[k]=v
    return {"mta":mta,"runtime":data,"exiwhat":exi[:100]}

@app.get("/api/smtp/connections")
def smtp_connections(hours:int=Query(4,ge=1,le=168), mta:str=Query("mta1")):
    validate_mta(mta)
    script=r'''set +e
emit_exim_log() {
  base="$1"
  for i in 10 9 8 7 6 5 4 3 2 1; do
    for f in "$base.$i.gz" "$base.$i"; do
      [ -r "$f" ] || continue
      case "$f" in *.gz) gzip -cd -- "$f" 2>/dev/null ;; *) cat -- "$f" ;; esac
    done
  done
  [ -r "$base" ] && cat -- "$base"
}
SINCE=$(date -d '__HOURS__ hours ago' '+%Y-%m-%d %H:%M:%S' 2>/dev/null)
echo '__ACTIVE__'
ss -Htn state established '( sport = :25 )' 2>/dev/null | head -100
echo '__CONNECTIONS__'
emit_exim_log /var/log/exim4/mainlog | awk -v s="$SINCE" 'substr($0,1,19)>=s && /SMTP connection from/ && $0 !~ / closed( |$)/' | tail -n 10000
'''.replace('__HOURS__',str(int(hours)))
    out=_remote_text(mta,script,25)
    active=[]; conns=[]; section=''
    for line in out.splitlines():
        if line=='__ACTIVE__': section='a'; continue
        if line=='__CONNECTIONS__': section='c'; continue
        if section=='a': active.append(line)
        elif section=='c': conns.append(line)
    dedup=[]; seen=set()
    for line in conns:
        cm=re.search(r'\bCi=([^ ]+)',line)
        key=cm.group(1) if cm else line
        if key in seen: continue
        seen.add(key); dedup.append(line)
    ips=defaultdict(int)
    for line in dedup:
        m=re.search(r'SMTP connection from.*?\[([^\]]+)\]',line)
        if m: ips[m.group(1)]+=1
    return {"mta":mta,"hours":hours,"active_count":len([x for x in active if x.strip()]),"active":active,
            "connection_attempts":len(dedup),"unique_sources":len(ips),
            "top_sources":[{"ip":ip,"connections":n} for ip,n in sorted(ips.items(),key=lambda x:x[1],reverse=True)[:20]],
            "recent_connections":dedup[-100:][::-1]}

@app.get("/api/smtp/queue")
def smtp_queue(mta:str=Query("mta1")):
    validate_mta(mta)
    script=r'''set +e
EXIM=$(command -v exim4 || command -v exim)
EXIM_CFG=""
[ -f /etc/exim4/exim4.conf.mobileum-safehold ] && EXIM_CFG="-C /etc/exim4/exim4.conf.mobileum-safehold"
$EXIM $EXIM_CFG -bp 2>/dev/null | head -n 500
'''
    out=_remote_text(mta,script,15)
    return {"mta":mta,"raw":out.splitlines()}

@app.get("/api/smtp/delivery")
def smtp_delivery(hours:int=Query(4,ge=1,le=24), mta:str=Query("mta1")):
    validate_mta(mta)
    script=r'''set +e
emit_exim_log() {
  base="$1"
  for i in 10 9 8 7 6 5 4 3 2 1; do
    for f in "$base.$i.gz" "$base.$i"; do
      [ -r "$f" ] || continue
      case "$f" in *.gz) gzip -cd -- "$f" 2>/dev/null ;; *) cat -- "$f" ;; esac
    done
  done
  [ -r "$base" ] && cat -- "$base"
}
SINCE=$(date -d '__HOURS__ hours ago' '+%Y-%m-%d %H:%M:%S' 2>/dev/null)
TMP=$(mktemp)
emit_exim_log /var/log/exim4/mainlog | awk -v s="$SINCE" 'substr($0,1,19)>=s' > "$TMP"
awk '/ <= /{c++} END{print "accepted=" c+0}' "$TMP"
awk '/ Completed$/{c++} END{print "completed=" c+0}' "$TMP"
awk '/ == /{c++} END{print "deferred=" c+0}' "$TMP"
awk '/ => / && /R=__PP__/{c++} END{print "proofpoint=" c+0}' "$TMP"
awk '/ == / && /R=__PP__/{c++} END{print "proofpoint_deferred=" c+0}' "$TMP"
awk '/ \*\* / && /R=__PP__/{c++} END{print "proofpoint_failed=" c+0}' "$TMP"
awk '/ => / && /R=__BA__/{c++} END{print "barracuda=" c+0}' "$TMP"
awk '/ == / && /R=__BA__/{c++} END{print "barracuda_deferred=" c+0}' "$TMP"
awk '/ \*\* / && /R=__BA__/{c++} END{print "barracuda_failed=" c+0}' "$TMP"
rm -f "$TMP"
'''.replace('__HOURS__',str(int(hours))).replace('__PP__',PP_ROUTER).replace('__BA__',BA_ROUTER)
    out=_remote_text(mta,script,25)
    d={}
    for line in out.splitlines():
        if '=' in line:
            k,v=line.split('=',1)
            try: d[k]=int(v)
            except Exception: d[k]=v
    d.update({"mta":mta,"hours":hours,"proofpoint_router":PP_ROUTER,"barracuda_router":BA_ROUTER,
              "unaccounted":None,
              "note":"Delivered, deferred and failed are Exim delivery events attributed to each configured router. Exact per-message dual-delivery correlation remains available in Message Trace."})
    return d

@app.get("/api/smtp/security")
def smtp_security(hours:int=Query(4,ge=1,le=168), mta:str=Query("mta1")):
    validate_mta(mta)
    script=r'''set +e
emit_exim_log() {
  base="$1"
  for i in 10 9 8 7 6 5 4 3 2 1; do
    for f in "$base.$i.gz" "$base.$i"; do
      [ -r "$f" ] || continue
      case "$f" in *.gz) gzip -cd -- "$f" 2>/dev/null ;; *) cat -- "$f" ;; esac
    done
  done
  [ -r "$base" ] && cat -- "$base"
}
SINCE=$(date -d '__HOURS__ hours ago' '+%Y-%m-%d %H:%M:%S' 2>/dev/null)
TM=$(mktemp); TR=$(mktemp); TP=$(mktemp)
emit_exim_log /var/log/exim4/mainlog | awk -v s="$SINCE" 'substr($0,1,19)>=s' > "$TM"
emit_exim_log /var/log/exim4/rejectlog | awk -v s="$SINCE" 'substr($0,1,19)>=s' > "$TR"
emit_exim_log /var/log/exim4/paniclog | awk -v s="$SINCE" 'substr($0,1,19)>=s' > "$TP"
printf 'reject_count=%s\n' "$(wc -l < "$TR")"
printf 'panic_count=%s\n' "$(wc -l < "$TP")"
CONNC=$(grep 'SMTP connection from' "$TM" | grep -vE ' closed( |$)' | sed -n 's/.* Ci=\([^ ]*\).*/\1/p' | sort -u | wc -l); [ "$CONNC" -gt 0 ] || CONNC=$(grep 'SMTP connection from' "$TM" | grep -vcE ' closed( |$)'); printf 'connection_starts=%s\n' "$CONNC"
printf 'unique_sources=%s\n' "$(grep 'SMTP connection from' "$TM" | grep -vE ' closed( |$)' | sed -n 's/.*SMTP connection from[^[]*\[\([^]]*\)\].*/\1/p' | sort -u | wc -l)"
printf 'connection_rejects=%s\n' "$(cat "$TM" "$TR" | grep -Eic 'connection (rejected|refused)|too many connections|SMTP connection.*(rejected|dropped)')"
printf 'lost_connections=%s\n' "$(grep -Eic 'unexpectedly closed|lost incoming connection|Connection reset by peer|connection lost' "$TM")"
printf 'no_mail=%s\n' "$(grep -Eic 'no MAIL' "$TM")"
printf 'incomplete_tx=%s\n' "$(grep -Eic 'incomplete.*transaction|transaction.*incomplete' "$TM")"
printf 'protocol_errors=%s\n' "$(grep -Eic 'SMTP protocol error|protocol error' "$TM")"
printf 'syntax_errors=%s\n' "$(grep -Eic 'SMTP syntax error|syntax error' "$TM")"
printf 'relay_attempts=%s\n' "$(grep -Eic 'relay not permitted|relay.*denied|not permitted to relay' "$TR")"
printf 'invalid_rcpt=%s\n' "$(grep -Eic 'invalid recipient|unknown recipient|unknown user|no such user|unrouteable address|recipient verify failed|recipient rejected' "$TR")"
TLSC=$(grep ' X=' "$TM" | sed -n 's/.* Ci=\([^ ]*\).*/\1/p' | sort -u | wc -l); [ "$TLSC" -gt 0 ] || TLSC=$(grep -c ' X=' "$TM"); printf 'tls_sessions=%s\n' "$TLSC"
echo '__TOP__'
{ grep 'SMTP connection from' "$TM"; cat "$TR"; } | sed -n 's/^[^[]*\[\([^]]*\)\].*/\1/p' | sort | uniq -c | sort -nr | head -20
echo '__REJECT__'; tail -n 150 "$TR"
echo '__PANIC__'; tail -n 100 "$TP"
rm -f "$TM" "$TR" "$TP"
'''.replace('__HOURS__',str(int(hours)))
    out=_remote_text(mta,script,30)
    metrics={}; top=[]; rejects=[]; panics=[]; sec='m'
    for line in out.splitlines():
        if line=='__TOP__': sec='t'; continue
        if line=='__REJECT__': sec='r'; continue
        if line=='__PANIC__': sec='p'; continue
        if sec=='m' and '=' in line:
            k,v=line.split('=',1)
            try: metrics[k]=int(v.strip())
            except Exception: metrics[k]=v.strip()
        elif sec=='t':
            m=re.match(r'\s*(\d+)\s+(.+)',line)
            if m: top.append({"ip":m.group(2).strip(),"count":int(m.group(1))})
        elif sec=='r': rejects.append(line)
        elif sec=='p': panics.append(line)
    return {"mta":mta,"hours":hours,**metrics,"top_rejected_sources":top,
            "recent_rejects":rejects[-100:][::-1],"recent_panics":panics[-50:][::-1]}

EMAIL_RX=re.compile(r'^[^@\s]{1,128}@[^@\s]{1,128}$')
TRACE_RX=re.compile(r'^[A-Za-z0-9-]{6,64}$')
EXIM_ID_RX=re.compile(r'\b([A-Za-z0-9]{6}-[A-Za-z0-9]{6,}-[A-Za-z0-9]{2,})\b')

def _extract_message_id(line):
    m=EXIM_ID_RX.search(line or "")
    return m.group(1) if m else ""

def _message_summary(message_id, lines, search_kind=None, search_query=None):
    sender=""; recipients=[]; source_ip=""; size=None; received_at=""; status="UNKNOWN"
    accepted=False; completed=False; frozen=False; deferred=False; failed=False; delivered=False
    proofpoint=False; barracuda=False
    for line in lines:
        if not received_at and len(line) >= 19 and re.match(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}', line):
            received_at=line[:19]
        if ' <= ' in line:
            accepted=True
            m=re.search(r' <= ([^ ]+)',line)
            if m: sender=m.group(1)
            ip=re.search(r' H=.*?\[([^\]]+)\]',line)
            if ip: source_ip=ip.group(1)
            sm=re.search(r'\bS=(\d+)\b',line)
            if sm:
                try: size=int(sm.group(1))
                except Exception: pass
            fm=re.search(r'\sfor\s+(.+)$',line)
            if fm:
                recipients.extend(re.findall(r'[^\s,]+@[^\s,]+',fm.group(1)))
        if ' => ' in line:
            delivered=True
            m=re.search(r' => ([^ ]+)',line)
            if m and '@' in m.group(1): recipients.append(m.group(1))
            if f'R={PP_ROUTER}' in line: proofpoint=True
            if f'R={BA_ROUTER}' in line: barracuda=True
        if ' == ' in line:
            deferred=True
            m=re.search(r' == ([^ ]+)',line)
            if m and '@' in m.group(1): recipients.append(m.group(1))
        if ' ** ' in line:
            failed=True
            m=re.search(r' \*\* ([^ ]+)',line)
            if m and '@' in m.group(1): recipients.append(m.group(1))
        if 'frozen by ACL' in line or re.search(r'\bfrozen\b',line,re.I): frozen=True
        if line.rstrip().endswith('Completed'): completed=True
    if search_kind=='recipient' and search_query and not recipients:
        recipients=[search_query]
    if search_kind=='sender' and search_query and not sender:
        sender=search_query
    recipients=list(dict.fromkeys(recipients))
    if failed: status='FAILED'
    elif deferred: status='DEFERRED'
    elif frozen: status='SAFE-HOLD' if any('frozen by ACL' in x for x in lines) else 'FROZEN'
    elif delivered and completed: status='COMPLETED'
    elif delivered: status='DELIVERED'
    elif accepted: status='ACCEPTED'
    return {"message_id":message_id,"time":received_at,"sender":sender,"recipients":recipients,
            "source_ip":source_ip,"size":size,"status":status,"accepted":accepted,
            "proofpoint_delivered":proofpoint,"barracuda_delivered":barracuda,
            "completed":completed,"frozen":frozen,"deferred":deferred,"failed":failed,
            "lines":lines}

def _trace_ids(mta, ids, timeout=30):
    clean=[]
    for mid in ids:
        if TRACE_RX.fullmatch(mid) and mid not in clean:
            clean.append(mid)
    if not clean: return {}
    clean=clean[:200]
    id_block='\n'.join(clean)
    script=r'''set +e
IDS=$(mktemp)
cat > "$IDS" <<'__IDS__'
__ID_BLOCK__
__IDS__
emit_exim_log() {
  base="$1"
  for i in 10 9 8 7 6 5 4 3 2 1; do
    for f in "$base.$i.gz" "$base.$i"; do
      [ -r "$f" ] || continue
      case "$f" in *.gz) gzip -cd -- "$f" 2>/dev/null ;; *) cat -- "$f" ;; esac
    done
  done
  [ -r "$base" ] && cat -- "$base"
}
{ emit_exim_log /var/log/exim4/mainlog; emit_exim_log /var/log/exim4/rejectlog; } | grep -Ff "$IDS" 2>/dev/null
rm -f "$IDS"
'''.replace('__ID_BLOCK__',id_block)
    out=_remote_text(mta,script,timeout)
    grouped={mid:[] for mid in clean}
    for line in out.splitlines():
        mid=_extract_message_id(line)
        if mid in grouped: grouped[mid].append(line)
    return grouped

@app.get("/api/smtp/search")
def smtp_search(kind:str|None=Query(None,max_length=32), query:str|None=Query(None,max_length=254),
                sender:str=Query("",max_length=254), recipient:str=Query("",max_length=254),
                message_id:str=Query("",max_length=64),
                hours:int=Query(24,ge=1,le=168), mta:str=Query("mta1")):
    # kind + query are retained for V9.0.5 API compatibility. New clients
    # send explicit sender/recipient/message_id fields. When sender and
    # recipient are both supplied they are AND-correlated by Exim Message-ID.
    validate_mta(mta)
    sender=(sender or "").strip()
    recipient=(recipient or "").strip()
    message_id=(message_id or "").strip()
    legacy_kind=(kind or "").lower().strip()
    legacy_query=(query or "").strip()

    # Backward compatibility with V9.0.5 callers/browser cache.
    if legacy_query and not (sender or recipient or message_id):
        if legacy_kind == "sender": sender=legacy_query
        elif legacy_kind == "recipient": recipient=legacy_query
        elif legacy_kind == "message_id": message_id=legacy_query
        else:
            return {"mta":mta,"kind":legacy_kind,"query":legacy_query,
                    "error":"kind must be recipient, sender or message_id","results":[]}

    criteria={"sender":sender,"recipient":recipient,"message_id":message_id}
    active=[k for k,v in criteria.items() if v]
    search_kind="combined" if len(active)>1 else (active[0] if active else "")

    if not active:
        return {"mta":mta,"kind":"","criteria":criteria,
                "error":"Enter a sender, recipient, or Exim Message-ID","results":[]}
    if sender and not EMAIL_RX.fullmatch(sender):
        return {"mta":mta,"kind":search_kind,"criteria":criteria,
                "error":"Enter a complete sender email address","results":[]}
    if recipient and not EMAIL_RX.fullmatch(recipient):
        return {"mta":mta,"kind":search_kind,"criteria":criteria,
                "error":"Enter a complete recipient email address","results":[]}
    if message_id and not TRACE_RX.fullmatch(message_id):
        return {"mta":mta,"kind":search_kind,"criteria":criteria,
                "error":"Invalid Exim Message-ID format","results":[]}

    # Exact Message-ID trace. Sender/recipient, when also supplied, are
    # additional AND filters instead of being silently ignored.
    if message_id:
        grouped=_trace_ids(mta,[message_id],20)
        lines=grouped.get(message_id,[])
        if not lines:
            return {"mta":mta,"kind":search_kind,"criteria":criteria,"hours":hours,
                    "count":0,"results":[],"rejected_matches":[],"warnings":[]}
        summary=_message_summary(message_id,lines)
        if sender and (summary.get('sender') or '').lower()!=sender.lower():
            return {"mta":mta,"kind":search_kind,"criteria":criteria,"hours":hours,
                    "count":0,"results":[],"rejected_matches":[],"warnings":[]}
        if recipient and not any(r.lower()==recipient.lower() for r in summary.get('recipients',[])):
            return {"mta":mta,"kind":search_kind,"criteria":criteria,"hours":hours,
                    "count":0,"results":[],"rejected_matches":[],"warnings":[]}
        return {"mta":mta,"kind":search_kind,"criteria":criteria,"hours":hours,"count":1,
                "results":[summary],"rejected_matches":[],"warnings":[]}

    # For sender+recipient, discover candidate IDs from the sender, trace each
    # ID, then require the recipient on the same transaction. This is the same
    # correlation model as the documented CLI workflow and does not assume
    # both addresses occur on one physical Exim log line.
    primary_kind='sender' if sender else 'recipient'
    primary_query=sender if sender else recipient
    q=shlex.quote(primary_query)
    qregex=shlex.quote(re.escape(primary_query))
    sregex=shlex.quote(re.escape(sender)) if sender else "''"
    rregex=shlex.quote(re.escape(recipient)) if recipient else "''"
    script=r'''set +e
QUERY=__QUERY__
QREGEX=__QREGEX__
SREGEX=__SREGEX__
RREGEX=__RREGEX__
emit_exim_log() {
  base="$1"
  for i in 10 9 8 7 6 5 4 3 2 1; do
    for f in "$base.$i.gz" "$base.$i"; do
      [ -r "$f" ] || continue
      case "$f" in *.gz) gzip -cd -- "$f" 2>/dev/null ;; *) cat -- "$f" ;; esac
    done
  done
  [ -r "$base" ] && cat -- "$base"
}
SINCE=$(date -d '__HOURS__ hours ago' '+%Y-%m-%d %H:%M:%S' 2>/dev/null)
EXIM=$(command -v exim4 || command -v exim)
EXIM_CFG=""
[ -f /etc/exim4/exim4.conf.mobileum-safehold ] && EXIM_CFG="-C /etc/exim4/exim4.conf.mobileum-safehold"
echo '__LOG_SELECTOR__'
$EXIM $EXIM_CFG -bP log_selector 2>/dev/null | sed 's/^[^=]*= *//'
echo '__MATCHES__'
{ emit_exim_log /var/log/exim4/mainlog; emit_exim_log /var/log/exim4/rejectlog; } \
 | awk -v s="$SINCE" 'substr($0,1,19)>=s' | grep -iF -- "$QUERY" | tail -n 4000
echo '__QUEUE_IDS__'
if command -v exiqgrep >/dev/null 2>&1; then
  if [ '__BOTH__' = 1 ]; then
    QS=$(mktemp); QR=$(mktemp)
    exiqgrep -i -f "$SREGEX" 2>/dev/null | sort -u > "$QS"
    exiqgrep -i -r "$RREGEX" 2>/dev/null | sort -u > "$QR"
    comm -12 "$QS" "$QR" | head -n 500
    rm -f "$QS" "$QR"
  elif [ '__PRIMARY_KIND__' = recipient ]; then
    exiqgrep -i -r "$QREGEX" 2>/dev/null | head -n 500
  else
    exiqgrep -i -f "$QREGEX" 2>/dev/null | head -n 500
  fi
fi
'''.replace('__QUERY__',q).replace('__QREGEX__',qregex).replace('__SREGEX__',sregex).replace('__RREGEX__',rregex).replace('__HOURS__',str(int(hours))).replace('__PRIMARY_KIND__',primary_kind).replace('__BOTH__','1' if sender and recipient else '0')
    out=_remote_text(mta,script,35)
    selector=''; matches=[]; queue_ids=[]; sec=''
    for line in out.splitlines():
        if line=='__LOG_SELECTOR__': sec='selector'; continue
        if line=='__MATCHES__': sec='matches'; continue
        if line=='__QUEUE_IDS__': sec='queue'; continue
        if sec=='selector': selector += (' ' if selector else '') + line.strip()
        elif sec=='matches': matches.append(line)
        elif sec=='queue':
            mid=line.strip()
            if TRACE_RX.fullmatch(mid): queue_ids.append(mid)

    ids=[]
    for line in matches:
        mid=_extract_message_id(line)
        if mid and mid not in ids: ids.append(mid)
    for mid in queue_ids:
        if mid not in ids: ids.append(mid)
    ids=ids[-200:]

    grouped=_trace_ids(mta,ids,40)
    results=[]
    slower=sender.lower() if sender else ''
    rlower=recipient.lower() if recipient else ''
    for mid in ids:
        lines=grouped.get(mid,[])
        summary=_message_summary(mid,lines)
        sender_match=(not sender) or (summary.get('sender') or '').lower()==slower
        recipient_match=(not recipient) or any(r.lower()==rlower for r in summary.get('recipients',[]))

        # A current-queue exiqgrep hit is authoritative for the primary filter
        # even if the receive line is no longer in retained logs.
        if mid in queue_ids:
            if sender:
                if not summary.get('sender'): summary['sender']=sender
                sender_match=True
            if recipient:
                if not summary.get('recipients'): summary['recipients']=[recipient]
                recipient_match=True

        if sender_match and recipient_match:
            results.append(summary)

    results.sort(key=lambda x:x.get('time') or '',reverse=True)
    rejected=[x for x in matches if not _extract_message_id(x)]
    if sender and recipient:
        rejected=[x for x in rejected if sender.lower() in x.lower() and recipient.lower() in x.lower()]
    elif sender:
        rejected=[x for x in rejected if sender.lower() in x.lower()]
    elif recipient:
        rejected=[x for x in rejected if recipient.lower() in x.lower()]

    warnings=[]
    if recipient and 'received_recipients' not in selector:
        warnings.append('Exim log_selector does not include received_recipients; current queued messages can still be found, but historical recipient correlation may be incomplete.')
    if sender and 'received_sender' not in selector:
        warnings.append('Exim log_selector does not include received_sender; normal <= lines still include the envelope sender, but enabling received_sender preserves the original unrewritten sender explicitly.')
    if sender and recipient:
        warnings.append('Sender + recipient uses Exim Message-ID correlation: candidate messages are found by sender and retained only when the same transaction contains the recipient.')

    return {"mta":mta,"kind":search_kind,"criteria":criteria,"hours":hours,"count":len(results),
            "results":results,"rejected_matches":rejected[-100:][::-1],"warnings":warnings,
            "log_selector":selector}

@app.get("/api/smtp/trace")
def smtp_trace(message_id:str=Query(...,min_length=6,max_length=64), mta:str=Query("mta1")):
    validate_mta(mta)
    if not TRACE_RX.fullmatch(message_id):
        return {"mta":mta,"message_id":message_id,"error":"Invalid Exim Message-ID format","lines":[]}
    grouped=_trace_ids(mta,[message_id],20)
    lines=grouped.get(message_id,[])[:1000]
    summary=_message_summary(message_id,lines)
    return {"mta":mta,"message_id":message_id,"accepted":summary["accepted"],
            "proofpoint_delivered":summary["proofpoint_delivered"],
            "barracuda_delivered":summary["barracuda_delivered"],"completed":summary["completed"],
            "status":summary["status"],"sender":summary["sender"],"recipients":summary["recipients"],
            "source_ip":summary["source_ip"],"size":summary["size"],"lines":lines}

