# Mobileum MTA Monitoring Dashboard V9.0.8

V9.0.8 runs centrally on the Jumpbox and uses the existing SSH aliases `mta1` and `mta2`. No dashboard agent is installed on either MTA and raw log trees are not copied to the Jumpbox.

## V9.0.8 changes

### Per-leg delivery outcomes

The SMTP / Exim Overview **Delivery Legs — last minute** panel now shows **Delivered**, **Deferred**, and **Failed** separately for both configured delivery routers:

```text
                 Delivered   Deferred   Failed
Proofpoint           16          4          0
Barracuda            20          0          0
```

Delivered is an Exim `=>` event, Deferred is a `==` event, and Failed is a `**` event. Deferred/failed events are attributed to a leg only when the corresponding Exim log line contains that configured router (`R=proofpoint_copy` or `R=barracuda_production`). The counts are delivery events in the rolling 60-second window, not an inferred failure count derived from the difference between the two Delivered values.

The Delivery tab also shows the same three outcomes for the selected historical window.

## Carried forward from V9.0.7

### Persistent MTA header metrics

V9.0.7 adds live host telemetry to **both** MTA health cards at the top of the dashboard, independent of the currently selected MTA:

```text
MTA1 · mta1.mobileum.com
HOST UP · EXIM ACTIVE · SMTP LISTENING · Queue 0
CPU 3.4% · RAM 5.2% · Load 0.61 · NET ↓ 0.04 Mbps ↑ 0.01 Mbps · ens5
Last seen: ...

MTA2 · mta2.mobileum.com
HOST UP · EXIM ACTIVE · SMTP LISTENING · Queue 0
CPU 7.1% · RAM 5.6% · Load 0.68 · NET ↓ 1.24 Mbps ↑ 0.18 Mbps · ens5
Last seen: ...
```

The collector samples both hosts every 15 seconds. CPU and network values are calculated from counter deltas between samples, while RAM is based on `MemAvailable`. The browser refreshes the two persistent health cards every 5 seconds, so the latest collected values remain visible while the operator works on either MTA. Network RX/TX is throughput over the collector interval, not a percentage of the EC2 network limit.


- Replaces the old Message Trace-only page with **Mail Search / Message Trace**.
- Search by **recipient email** to list messages received for a Mobileum employee.
- Search by **sender email** to investigate whether mail from an external sender reached the MTA.
- Search by **Exim Message-ID** for a complete transaction trace.
- Results show received time, Exim ID, envelope sender, envelope recipient(s), source IP, size and current/final disposition.
- A **Trace** button on every result expands the complete Exim log history for that message.
- Displays **Rejected / Pre-Acceptance Matches** separately. This is important when a remote sender was rejected before a normal message trace existed.
- Classifies `frozen by ACL` as **SAFE-HOLD**, distinguishing our deliberate test hold from a production delivery problem.
- Removes the duplicate **SMTP Connections / selected window** and **Queue Depth / selected window** graphs from the SMTP Overview page. Their numeric counters remain. Detailed operational pages remain available.
- Upgrade installer now stops/restarts existing services, checks SQLite writability as the dashboard user, and preserves the existing SQLite history.
- **Fixes the confirmed SQLite file-descriptor leak** in V9.0.5. Every database context now commits/rolls back and explicitly closes the SQLite connection.
- Mail Search now has separate **Sender**, **Recipient**, and **Exim Message-ID** fields. Sender + recipient can be entered together and are AND-correlated by Exim Message-ID.
- Preserves backward compatibility with the V9.0.5 `kind` + `query` search API.
- Verification includes a repeated `/api/health` file-descriptor leak check.

## Search sources

The search API queries the selected MTA on demand:

- `/var/log/exim4/mainlog`
- `/var/log/exim4/mainlog.1` ... rotations including `.gz`
- `/var/log/exim4/rejectlog`
- rotated reject logs including `.gz`
- current Exim queue via `exiqgrep` when available

The browser never SSHs to an MTA directly. FastAPI on the Jumpbox performs the bounded read-only SSH query.

## Important Exim logging for recipient investigations

For reliable historical searches by recipient, Exim must have these selectors in the active `log_selector`:

```text
+received_recipients
+received_sender
```

`received_recipients` causes the accepted envelope recipient list to be written on the `<=` receive line. This allows a later search such as `Venkatesh.AK@mobileum.com` even after the message has left the queue.

The existing telemetry selectors should remain; extend the existing `log_selector`, do not add a second `log_selector` directive.

Check MTA2 from the Jumpbox with:

```bash
./bin/check-mail-search-logging.sh mta2
```

## Upgrade on Jumpbox

```bash
cd ~/mta
unzip mobileum_dashboard_v9_0_8.zip
cd mobileum_dashboard_v9_0_8
sudo ./bin/install-jumpbox.sh
sudo ./bin/verify.sh
```

The installer preserves:

```text
/opt/mobileum-mta-dashboard/data/monitoring.db
```

and explicitly restarts:

```text
mobileum-mta-collector.service
mobileum-mta-dashboard.service
```

## Post-upgrade verification

After installation:

```bash
sudo ./bin/verify.sh
```

The V9.0.8 verification script deliberately calls `/api/health` repeatedly and checks the dashboard/collector SQLite descriptor counts. The regression check should end with:

```text
SQLite descriptor leak check: PASS
```

You can also check current descriptor usage at any time:

```bash
sudo /opt/mobileum-mta-dashboard/bin/check-dashboard-fds.sh
```

Healthy behavior is a low, approximately stable FD count. SQLite descriptors should not continuously increase after repeated browser refreshes or 15-second collector cycles.

## Rollback safety

The installer preserves the existing SQLite history and also copies the immediately previous application code to a timestamped directory under:

```text
/opt/mobileum-mta-dashboard/backups/pre-v9.0.8-<timestamp>/
```

The backup is application code only; `data/monitoring.db` remains in place and is not replaced by the upgrade.

## Mail Search usage

Select the MTA and time window, then open:

```text
SMTP / Exim -> Mail Search / Trace
```

Examples:

```text
Sender email:    sender@example.com
Recipient email: Venkatesh.AK@mobileum.com

# Use both fields together for sender + recipient correlation.
# Or use an exact Exim ID:
Message-ID:      1x8Gvu-00000000aXh-22l8
```

Sender and recipient may be used independently or together. Combined sender + recipient searches discover candidate messages and correlate them by Exim Message-ID before returning only transactions that satisfy both addresses. Searches return up to 200 matching message IDs for the selected window/current queue. Rejected events that do not have a normal message ID are shown separately when they can be matched.

## Architecture

```text
MTA1 -- bounded SSH reads --\
                             +--> Jumpbox FastAPI --> HTML dashboard
MTA2 -- bounded SSH reads --/
                 |
                 +--> 15-second aggregate collector --> SQLite history
```

## Existing dashboard areas

OS/security:

- SSH Access
- Failed Logins
- Sudo Activity
- System Audit

SMTP/Exim:

- Overview
- Connections
- Queue
- Delivery
- Security
- Mail Search / Trace

## Services

```bash
systemctl status mobileum-mta-collector --no-pager
systemctl status mobileum-mta-dashboard --no-pager
```

Dashboard listener:

```text
127.0.0.1:8089
```

Keep the FastAPI listener private on `127.0.0.1:8089`. Customer access should continue through the existing Jumpbox Nginx HTTPS reverse proxy; do not expose port 8089 publicly.
