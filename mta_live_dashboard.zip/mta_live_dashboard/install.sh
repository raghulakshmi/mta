#!/usr/bin/env bash
set -euo pipefail

APP_DIR=/opt/mta-access-dashboard

sudo apt-get update
sudo apt-get install -y python3-venv python3-pip

sudo mkdir -p "$APP_DIR/static"
sudo cp app.py "$APP_DIR/"
sudo cp static/index.html "$APP_DIR/static/"
sudo cp requirements.txt "$APP_DIR/"

sudo python3 -m venv "$APP_DIR/venv"
sudo "$APP_DIR/venv/bin/pip" install --upgrade pip
sudo "$APP_DIR/venv/bin/pip" install -r "$APP_DIR/requirements.txt"

sudo cp mta-access-dashboard.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now mta-access-dashboard

echo
echo "Service status:"
sudo systemctl --no-pager --full status mta-access-dashboard || true
echo
echo "Local test:"
curl -s http://127.0.0.1:8088/api/summary?hours=4 | head -c 500 || true
echo
echo
echo "Dashboard listens ONLY on 127.0.0.1:8088."
echo "Use an SSH tunnel:"
echo "  ssh -L 8088:127.0.0.1:8088 <user>@<mta-ip>"
echo "Then browse: http://127.0.0.1:8088"
