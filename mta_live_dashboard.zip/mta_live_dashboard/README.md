# MTA Access Security Dashboard

Live Ubuntu SSH access dashboard for the MTA hosts.

## What it shows

- Active SSH sessions
- Successful logins
- Failed logins
- Invalid-user attempts
- Unique source IPs
- High/Critical access events
- Recent SSH authentication activity
- Top source IPs
- Per-user activity
- Current sessions

The browser refreshes automatically every 5 seconds.

Time windows:
- 4 hours
- 8 hours
- 12 hours
- 24 hours
- 48 hours
- Custom (1–720 hours)

## Data source

The backend reads:

```bash
journalctl -u ssh --since "<N> hours ago" -o short-iso
```

and active sessions from:

```bash
who
```

## Install on Ubuntu 24.04

Copy this directory to MTA1 and run:

```bash
chmod +x install.sh
./install.sh
```

## Security posture

The service intentionally binds only to:

```text
127.0.0.1:8088
```

Do **not** open port 8088 in the EC2 security group.

Access it through your existing restricted SSH path:

```bash
ssh -L 8088:127.0.0.1:8088 ubuntu@<MTA_PUBLIC_IP>
```

Then browse locally:

```text
http://127.0.0.1:8088
```

## Verify

```bash
sudo systemctl status mta-access-dashboard
curl http://127.0.0.1:8088/api/summary?hours=24
```

## Notes

This first production version intentionally does not require Prometheus or Grafana.

The current risk correlation is intentionally conservative and simple:
- repeated failures from the same IP increase severity
- success from an IP with repeated failures becomes Critical
- invalid-user and root-login attempts are surfaced prominently

Next hardening iterations can add:
- approved-source-IP awareness
- SSH key fingerprints
- success-after-failure correlation by username + IP + time window
- sudo command telemetry
- auditd events
- GeoIP / ASN enrichment
- persistent event database
