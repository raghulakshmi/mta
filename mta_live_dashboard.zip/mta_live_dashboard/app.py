from fastapi import FastAPI, Query
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
import subprocess
import re

app = FastAPI(title="MTA Access Security Dashboard")

BASE = Path(__file__).resolve().parent
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

SSH_PATTERNS = [
    ("success", re.compile(r"Accepted (?P<method>\S+) for (?P<user>\S+) from (?P<ip>\S+) port (?P<port>\d+)")),
    ("failed", re.compile(r"Failed (?P<method>\S+) for (?:invalid user )?(?P<user>\S+) from (?P<ip>\S+) port (?P<port>\d+)")),
    ("invalid", re.compile(r"Invalid user (?P<user>\S+) from (?P<ip>\S+)")),
    ("opened", re.compile(r"session opened for user (?P<user>\S+)")),
    ("closed", re.compile(r"session closed for user (?P<user>\S+)")),
]

def run(cmd):
    try:
        return subprocess.check_output(cmd, text=True, stderr=subprocess.DEVNULL)
    except Exception:
        return ""

def get_ssh_lines(hours: int):
    out = run([
        "journalctl", "-u", "ssh",
        "--since", f"{hours} hours ago",
        "--no-pager",
        "-o", "short-iso"
    ])
    return out.splitlines()

def parse_line(line: str):
    # short-iso starts with timestamp in first token.
    parts = line.split(" ", 1)
    if not parts:
        return None
    ts = parts[0]
    try:
        dt = datetime.fromisoformat(ts.replace("Z","+00:00"))
    except Exception:
        dt = datetime.now(timezone.utc)

    for etype, rx in SSH_PATTERNS:
        m = rx.search(line)
        if not m:
            continue
        d = m.groupdict()
        user = d.get("user") or ""
        ip = d.get("ip") or ""
        method = d.get("method") or ""
        port = d.get("port") or ""
        risk = "Normal"
        if etype == "failed":
            risk = "Medium"
        if etype == "invalid":
            risk = "High"
        if user == "root" and etype in ("failed","invalid"):
            risk = "High"
        return {
            "timestamp": dt.isoformat(),
            "event_type": etype,
            "username": user,
            "source_ip": ip,
            "source_port": port,
            "method": method,
            "result": "SUCCESS" if etype == "success" else ("FAILED" if etype in ("failed","invalid") else etype.upper()),
            "risk": risk,
            "raw": line,
        }
    return None

def get_events(hours: int):
    events = []
    for line in get_ssh_lines(hours):
        e = parse_line(line)
        if e:
            events.append(e)

    # Correlate repeated failures per IP and success-after-failures.
    fail_counts = defaultdict(int)
    for e in events:
        if e["result"] == "FAILED" and e["source_ip"]:
            fail_counts[e["source_ip"]] += 1

    for e in events:
        ip = e["source_ip"]
        if e["result"] == "FAILED" and ip:
            if fail_counts[ip] >= 10:
                e["risk"] = "High"
            elif fail_counts[ip] >= 5:
                e["risk"] = "Medium"
        if e["result"] == "SUCCESS" and ip and fail_counts[ip] >= 5:
            e["risk"] = "Critical"

    events.sort(key=lambda x: x["timestamp"], reverse=True)
    return events

def current_sessions():
    out = run(["who"])
    sessions = []
    for line in out.splitlines():
        # Typical: user pts/0 2026-09-05 11:17 (45.119.114.19)
        m = re.match(r"(?P<user>\S+)\s+(?P<tty>\S+)\s+(?P<date>\S+)\s+(?P<time>\S+)\s+\((?P<ip>[^)]+)\)", line)
        if m:
            sessions.append(m.groupdict())
    return sessions

@app.get("/", response_class=HTMLResponse)
def index():
    return (BASE / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/api/events")
def api_events(hours: int = Query(24, ge=1, le=720)):
    events = get_events(hours)
    return {"hours": hours, "events": events}

@app.get("/api/sessions")
def api_sessions():
    return {"sessions": current_sessions()}

@app.get("/api/summary")
def api_summary(hours: int = Query(24, ge=1, le=720)):
    events = get_events(hours)
    sessions = current_sessions()
    success = [e for e in events if e["result"] == "SUCCESS"]
    failed = [e for e in events if e["result"] == "FAILED"]
    invalid = [e for e in events if e["event_type"] == "invalid"]
    ips = sorted({e["source_ip"] for e in events if e["source_ip"]})
    critical = [e for e in events if e["risk"] == "Critical"]

    by_ip = defaultdict(lambda: {"attempts":0, "success":0, "failures":0, "users":set()})
    by_user = defaultdict(lambda: {"success":0, "failures":0, "ips":set(), "last_seen":None})

    for e in events:
        ip, user = e["source_ip"], e["username"]
        if ip:
            by_ip[ip]["attempts"] += 1
            if e["result"] == "SUCCESS":
                by_ip[ip]["success"] += 1
            elif e["result"] == "FAILED":
                by_ip[ip]["failures"] += 1
            if user:
                by_ip[ip]["users"].add(user)
        if user:
            if e["result"] == "SUCCESS":
                by_user[user]["success"] += 1
            elif e["result"] == "FAILED":
                by_user[user]["failures"] += 1
            if ip:
                by_user[user]["ips"].add(ip)
            if by_user[user]["last_seen"] is None or e["timestamp"] > by_user[user]["last_seen"]:
                by_user[user]["last_seen"] = e["timestamp"]

    return {
        "hours": hours,
        "kpis": {
            "active_sessions": len(sessions),
            "successful_logins": len(success),
            "failed_logins": len(failed),
            "invalid_users": len(invalid),
            "unique_source_ips": len(ips),
            "critical_alerts": len(critical),
        },
        "top_ips": [
            {"ip": ip, "attempts": v["attempts"], "success": v["success"],
             "failures": v["failures"], "users": sorted(v["users"])}
            for ip, v in sorted(by_ip.items(), key=lambda x: x[1]["attempts"], reverse=True)
        ][:20],
        "users": [
            {"user": user, "success": v["success"], "failures": v["failures"],
             "unique_ips": len(v["ips"]), "last_seen": v["last_seen"]}
            for user, v in by_user.items()
        ],
        "alerts": [e for e in events if e["risk"] in ("High","Critical")][:20],
        "events": events[:200],
        "sessions": sessions,
    }
