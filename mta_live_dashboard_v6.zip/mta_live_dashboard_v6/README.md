# MTA Dashboard v6 — Extended Exim Audit

## What changed

The Audit Changes tab now accepts any audit key beginning with:

```text
exim_
```

So future Exim-related audit categories automatically appear without another dashboard code change.

Initial categories supported by the rule installer:

- `exim_config` — `/etc/exim4/`
- `exim_service` — `/etc/default/exim4`
- `exim_systemd` — Exim systemd unit/drop-ins under `/etc/systemd/system`
- `exim_maps` — custom maps directory if it exists
- `exim_scripts` — custom script directory if it exists
- `exim_custom` — local Exim configuration directory if it exists

The installer only creates watches for paths that already exist.

## Upgrade dashboard

```bash
chmod +x upgrade.sh
./upgrade.sh
```

## Install/refresh focused Exim audit rules

```bash
chmod +x install-audit-rules.sh
./install-audit-rules.sh
```

Verify:

```bash
sudo auditctl -l | grep exim_
```

## TLS

TLS certificate/private-key paths are deliberately not guessed or watched broadly.

After confirming the exact paths used by Exim, add file-specific watches such as:

```text
-w /exact/path/to/certificate.pem -p wa -k exim_tls_cert
-w /exact/path/to/private-key.pem  -p wa -k exim_tls_key
```

Do not recursively audit all of `/etc/ssl/private`, because that can capture unrelated services and create unnecessary noise.

## What not to watch

Do not recursively watch `/var/spool/exim4` for normal writes. Message queue activity would create very high audit volume.
