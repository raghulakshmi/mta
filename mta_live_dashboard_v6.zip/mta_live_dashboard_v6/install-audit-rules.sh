#!/usr/bin/env bash
set -euo pipefail

RULE_FILE="/etc/audit/rules.d/mta-exim.rules"
TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT

echo "# Managed Exim-focused audit rules" > "$TMP"
echo "# Generated: $(date -Is)" >> "$TMP"
echo >> "$TMP"

add_watch() {
    local path="$1"
    local key="$2"

    if [[ -e "$path" ]]; then
        printf '%s\n' "-w $path -p wa -k $key" >> "$TMP"
        echo "ADD  $key  $path"
    else
        echo "SKIP $key  $path (not present)"
    fi
}

# Core Exim configuration.
add_watch "/etc/exim4/" "exim_config"

# Service/environment configuration if present.
add_watch "/etc/default/exim4" "exim_service"
add_watch "/etc/systemd/system/exim4.service" "exim_systemd"
add_watch "/etc/systemd/system/exim4.service.d/" "exim_systemd"

# Optional local directories commonly used for custom maps/scripts.
# These are only enabled if they already exist.
add_watch "/etc/exim4/maps/" "exim_maps"
add_watch "/etc/exim4/scripts/" "exim_scripts"
add_watch "/usr/local/lib/exim4/" "exim_scripts"
add_watch "/usr/local/etc/exim4/" "exim_custom"

echo
echo "Candidate rules:"
cat "$TMP"

echo
echo "Installing $RULE_FILE"
sudo install -o root -g root -m 0640 "$TMP" "$RULE_FILE"

echo "Loading rules..."
sudo augenrules --load

echo
echo "Loaded Exim audit watches:"
sudo auditctl -l | grep -E 'key=exim_|-k exim_' || true

echo
echo "NOTE:"
echo "TLS certificate/key paths are NOT watched automatically."
echo "After we confirm the exact Exim TLS certificate/private-key paths, add only those specific files"
echo "with keys exim_tls_cert and exim_tls_key. Do not watch all of /etc/ssl/private recursively."
