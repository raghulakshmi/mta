#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/mta-access-dashboard"
SERVICE="mta-access-dashboard"

[[ -d "$APP_DIR" ]] || { echo "ERROR: $APP_DIR not found"; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/opt/mta-access-dashboard-backup-$STAMP"

echo "Backing up dashboard to $BACKUP"
sudo cp -a "$APP_DIR" "$BACKUP"

echo "Installing v6 application..."
sudo install -m 0644 app.py "$APP_DIR/app.py"
sudo install -m 0644 static/index.html "$APP_DIR/static/index.html"

echo "Restarting dashboard..."
sudo systemctl restart "$SERVICE"

echo "Waiting for APIs..."
READY=0
for i in {1..15}; do
    if curl -fsS "http://127.0.0.1:8088/api/audit?hours=4" >/tmp/mta-v6-audit.json 2>/dev/null; then
        READY=1
        echo "Audit API ready after ${i}s."
        break
    fi
    sleep 1
done

if [[ "$READY" -ne 1 ]]; then
    echo "ERROR: dashboard did not become ready"
    sudo journalctl -u "$SERVICE" -n 100 --no-pager
    exit 1
fi

echo
echo "Current Exim audit events:"
python3 - <<'PY'
import json
d=json.load(open('/tmp/mta-v6-audit.json'))
print("events:", len(d.get("events", [])))
for e in d.get("events", [])[:10]:
    print(e.get("timestamp"), e.get("category"), e.get("action"), e.get("path"), e.get("command"))
PY

echo
echo "Dashboard v6 upgrade complete."
echo "Backup: $BACKUP"
echo
echo "Next, if not already done:"
echo "  chmod +x install-audit-rules.sh"
echo "  ./install-audit-rules.sh"
