#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/mta-access-dashboard"
SERVICE="mta-access-dashboard"

[[ -d "$APP_DIR" ]] || { echo "ERROR: $APP_DIR not found"; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/opt/mta-access-dashboard-backup-$STAMP"

echo "Backing up current dashboard to $BACKUP"
sudo cp -a "$APP_DIR" "$BACKUP"

echo "Installing v8..."
sudo install -m 0644 app.py "$APP_DIR/app.py"
sudo install -m 0644 static/index.html "$APP_DIR/static/index.html"

echo "Restarting service..."
sudo systemctl restart "$SERVICE"

echo "Waiting for API..."
for i in {1..15}; do
  if curl -fsS "http://127.0.0.1:8088/api/summary?hours=4" >/tmp/mta-v8-ssh.json 2>/dev/null; then
    echo "API ready after ${i}s."
    break
  fi
  sleep 1
done

echo
echo "Checking v8 frontend..."
grep -q "Failed Logins" "$APP_DIR/static/index.html"
grep -q "renderFailed" "$APP_DIR/static/index.html"
echo "v8 frontend installed."

echo
echo "Upgrade complete."
echo "Backup: $BACKUP"
