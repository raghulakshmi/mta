# MTA Dashboard v8

Adds a dedicated **Failed Logins** tab.

The tab derives data from the existing SSH API and shows:

- failed authentication count
- invalid-user attempts
- handshake/pre-auth disconnects
- unique failed source IPs
- failed-event table
- top failed source IPs
- failed usernames
- failure-type breakdown

No backend log source changes are required.
