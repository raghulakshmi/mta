
from fastapi import FastAPI, Query
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
import subprocess, re, pwd, binascii

app = FastAPI(title="MTA Access Security Dashboard v4")
BASE = Path(__file__).resolve().parent
app.mount("/static", StaticFiles(directory=BASE/"static"), name="static")

def run(cmd):
    try:
        return subprocess.check_output(cmd, text=True, stderr=subprocess.DEVNULL)
    except Exception:
        return ""

def uid_name(uid):
    try:
        return pwd.getpwuid(int(uid)).pw_name
    except Exception:
        return str(uid)

def parse_iso_ts(line):
    token = line.split(" ",1)[0] if line else ""
    try:
        return datetime.fromisoformat(token.replace("Z","+00:00")).isoformat()
    except Exception:
        return datetime.now(timezone.utc).isoformat()

# -----------------------------
# SSH
# -----------------------------
RX_CONN=re.compile(r"Connection from (?P<src_ip>\S+) port (?P<src_port>\d+) on (?P<dst_ip>\S+) port (?P<dst_port>\d+)")
RX_KEY=re.compile(r"Accepted key (?P<key_type>\S+) (?P<fingerprint>SHA256:\S+) found at (?P<auth_file>\S+):(?P<auth_line>\d+)")
RX_OK=re.compile(r"Accepted (?P<method>\S+) for (?P<user>\S+) from (?P<src_ip>\S+) port (?P<src_port>\d+) ssh2(?:: (?P<key_type>\S+) (?P<fingerprint>SHA256:\S+))?")
RX_FAIL=re.compile(r"Failed (?P<method>\S+) for (?:invalid user )?(?P<user>\S+) from (?P<src_ip>\S+) port (?P<src_port>\d+)")
RX_INVALID=re.compile(r"Invalid user (?P<user>\S+) from (?P<src_ip>\S+)")
RX_OPEN=re.compile(r"session opened for user (?P<user>\S+)\(uid=(?P<uid>\d+)\)")
RX_CHILD=re.compile(r"User child is on pid (?P<pid>\d+)")
RX_KEX=re.compile(r"kex_exchange_identification: Connection closed by remote host")

def blank_ssh(t):
    return dict(timestamp=t,event_stage="",username="",source_ip="",source_port="",
                destination_ip="",destination_port="",result="",method="",key_type="",
                key_fingerprint="",authorized_keys_file="",authorized_keys_line="",
                sshd_pid="",session_pid="",risk="Normal",raw="")

def ssh_events(hours):
    out=run(["journalctl","-u","ssh","--since",f"{hours} hours ago","--no-pager","-o","short-iso"])
    pending={}; ev=[]
    for line in out.splitlines():
        t=parse_iso_ts(line)
        pm=re.search(r"sshd\[(\d+)\]",line); pid=pm.group(1) if pm else ""
        c=pending.setdefault(pid,blank_ssh(t)); c["sshd_pid"]=pid
        m=RX_CONN.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Connection",source_ip=d["src_ip"],source_port=d["src_port"],
                destination_ip=d["dst_ip"],destination_port=d["dst_port"],result="CONNECTED",raw=line); ev.append(dict(c)); continue
        m=RX_KEY.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Key accepted",key_type=d["key_type"],key_fingerprint=d["fingerprint"],
                authorized_keys_file=d["auth_file"],authorized_keys_line=d["auth_line"],result="KEY_ACCEPTED",raw=line); ev.append(dict(c)); continue
        m=RX_OK.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Authentication success",username=d["user"],source_ip=d["src_ip"],
                source_port=d["src_port"],result="SUCCESS",method=d["method"],key_type=d.get("key_type") or c["key_type"],
                key_fingerprint=d.get("fingerprint") or c["key_fingerprint"],raw=line); ev.append(dict(c)); continue
        m=RX_FAIL.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Authentication failure",username=d["user"],source_ip=d["src_ip"],
                source_port=d["src_port"],result="FAILED",method=d["method"],risk="Medium",raw=line); ev.append(dict(c)); continue
        m=RX_INVALID.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Invalid user",username=d["user"],source_ip=d["src_ip"],
                result="FAILED",risk="High",raw=line); ev.append(dict(c)); continue
        m=RX_OPEN.search(line)
        if m:
            c.update(timestamp=t,event_stage="Session opened",username=m["user"],result="SESSION_OPEN",raw=line); ev.append(dict(c)); continue
        m=RX_CHILD.search(line)
        if m:
            c.update(timestamp=t,event_stage="Session child",session_pid=m["pid"],result="SESSION_ACTIVE",raw=line); ev.append(dict(c)); continue
        if RX_KEX.search(line):
            c.update(timestamp=t,event_stage="Handshake failure",result="PREAUTH_DISCONNECT",risk="Medium",raw=line); ev.append(dict(c)); continue

    fails=defaultdict(int)
    for e in ev:
        if e["result"]=="FAILED" and e["source_ip"]:
            fails[e["source_ip"]]+=1
    for e in ev:
        ip=e["source_ip"]
        if e["result"]=="FAILED" and ip and fails[ip]>=10: e["risk"]="High"
        if e["result"]=="SUCCESS" and ip and fails[ip]>=5: e["risk"]="Critical"
    ev.sort(key=lambda x:x["timestamp"],reverse=True)
    return ev

def current_sessions():
    s=[]
    for line in run(["who"]).splitlines():
        m=re.match(r"(?P<user>\S+)\s+(?P<tty>\S+)\s+(?P<date>\S+)\s+(?P<time>\S+)\s+\((?P<ip>[^)]+)\)",line)
        if m: s.append(m.groupdict())
    return s

# -----------------------------
# Sudo - multiline Ubuntu format
# -----------------------------
SUDO_START_RX = re.compile(r'^[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+:\s+')

def join_sudo_records(lines):
    records=[]; current=""
    for line in lines:
        if SUDO_START_RX.match(line):
            if current: records.append(current.strip())
            current=line.strip()
        elif current:
            current += " " + line.strip()
    if current: records.append(current.strip())
    return records

def parse_sudo_record(record, now):
    m=re.match(r'^(?P<mon>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+(?P<time>\d{2}:\d{2}:\d{2})\s+:\s+(?P<user>[^:]+?)\s+:\s+(?P<body>.*)$',record)
    if not m: return None
    body=m.group("body")
    def field(name):
        fm=re.search(rf'(?:^|;\s*){re.escape(name)}=(.*?)(?=\s*;\s*[A-Z]+(?:_[A-Z]+)?=|$)',body)
        return fm.group(1).strip() if fm else ""
    cm=re.search(r'(?:^|;\s*)COMMAND=(.*)$',body)
    try:
        dt=datetime.strptime(f'{now.year} {m.group("mon")} {m.group("day")} {m.group("time")}',"%Y %b %d %H:%M:%S")
        if dt.timestamp()>now.timestamp()+86400: dt=dt.replace(year=now.year-1)
    except Exception:
        dt=now
    return {"timestamp":dt.astimezone().isoformat(),"timestamp_epoch":dt.timestamp(),
            "username":m.group("user").strip(),"tty":field("TTY"),"pwd":field("PWD"),
            "run_as":field("USER"),"tsid":field("TSID"),"command":cm.group(1).strip() if cm else "",
            "raw":record}

def classify_sudo(command):
    c=command.lower()
    if any(x in c for x in ["rm -rf /var/spool/exim","systemctl stop ssh","systemctl disable ssh"]): return "Critical"
    if any(x in c for x in ["iptables","nft ","nftables","ufw ","/etc/exim4","/etc/ssh/","useradd","usermod","passwd ","visudo","/etc/sudoers"]): return "High"
    if any(x in c for x in ["systemctl restart","systemctl reload","apt install","apt remove","apt purge","apt upgrade","apt full-upgrade"]): return "Medium"
    return "Normal"

def sudo_events(hours):
    path=Path("/var/log/sudo.log")
    if not path.exists(): return []
    try: lines=path.read_text(errors="replace").splitlines()
    except Exception: return []
    now=datetime.now(); cutoff=now.timestamp()-hours*3600
    ev=[]
    for record in join_sudo_records(lines[-10000:]):
        e=parse_sudo_record(record,now)
        if not e or e["timestamp_epoch"]<cutoff: continue
        e["risk"]=classify_sudo(e["command"]); e.pop("timestamp_epoch",None); ev.append(e)
    ev.sort(key=lambda x:x["timestamp"],reverse=True)
    return ev

# -----------------------------
# Auditd - Exim config changes
# -----------------------------
AUDIT_ID_RX = re.compile(r'msg=audit\((?P<epoch>\d+(?:\.\d+)?):(?P<serial>\d+)\)')
KV_RX = re.compile(r'(\w+)=("[^"]*"|\S+)')

def kv(line):
    out={}
    for k,v in KV_RX.findall(line):
        if len(v)>=2 and v[0]=='"' and v[-1]=='"':
            v=v[1:-1]
        out[k]=v
    return out

def decode_proctitle(value):
    if not value: return ""
    try:
        b=binascii.unhexlify(value)
        return " ".join(x.decode(errors="replace") for x in b.split(b"\x00") if x)
    except Exception:
        return value

def audit_exim_events(hours):
    path=Path("/var/log/audit/audit.log")
    if not path.exists(): return []
    try: lines=path.read_text(errors="replace").splitlines()
    except Exception: return []

    cutoff=datetime.now().timestamp()-hours*3600
    grouped=defaultdict(list)

    for line in lines[-30000:]:
        m=AUDIT_ID_RX.search(line)
        if m:
            grouped[(m.group("epoch"),m.group("serial"))].append(line)

    events=[]
    for (epoch,serial), rows in grouped.items():
        if float(epoch)<cutoff: continue

        # Require a real syscall carrying one of the focused MTA audit keys.
        supported_keys = {
            "exim_config", "exim_service", "exim_systemd", "exim_maps",
            "exim_scripts", "exim_custom", "exim_tls_cert", "exim_tls_key",
            "ssh_config",
            "privilege_config", "privilege_change",
            "identity", "identity_change",
            "systemd_config", "service_change",
            "network_config", "network_change",
            "firewall_config", "firewall_change",
            "audit_config"
        }
        syscall_line = None
        category = None
        for r in rows:
            if not r.startswith("type=SYSCALL"):
                continue
            km = re.search(r'key="(?P<key>[^"]+)"', r)
            if km and km.group("key") in supported_keys:
                syscall_line = r
                category = km.group("key")
                break
        if not syscall_line:
            continue

        sk=kv(syscall_line)
        paths=[]
        action="CHANGE"
        for r in rows:
            if r.startswith("type=PATH"):
                p=kv(r)
                name=p.get("name","")
                nt=p.get("nametype","")
                # Ignore parent directory entry when a child path is available
                if name:
                    paths.append((name,nt))
                    if nt=="CREATE": action="CREATE"
                    elif nt=="DELETE": action="DELETE"

        chosen=""
        for name,nt in paths:
            if nt not in ("PARENT",):
                chosen=name
                break
        if not chosen and paths:
            chosen=paths[0][0]

        cwd_line=next((r for r in rows if r.startswith("type=CWD")), "")
        cwd=kv(cwd_line).get("cwd","") if cwd_line else ""

        pt_line=next((r for r in rows if r.startswith("type=PROCTITLE")), "")
        pt=kv(pt_line).get("proctitle","") if pt_line else ""
        command=decode_proctitle(pt)

        auid=sk.get("auid","")
        uid=sk.get("uid","")
        euid=sk.get("euid","")
        success=sk.get("success","")
        comm=sk.get("comm","")
        exe=sk.get("exe","")
        tty=sk.get("tty","")
        ses=sk.get("ses","")
        event_time=datetime.fromtimestamp(float(epoch)).astimezone().isoformat()

        family = (
            "Exim" if category.startswith("exim_") else
            "SSH" if category == "ssh_config" else
            "Privilege" if category.startswith("privilege_") else
            "Identity" if category.startswith("identity") else
            "Service" if category in {"systemd_config","service_change"} else
            "Network" if category.startswith("network_") else
            "Firewall" if category.startswith("firewall_") else
            "Audit Security" if category == "audit_config" else
            "Other"
        )

        risk = (
            "Critical" if category == "audit_config" else
            "High" if category in {
                "privilege_config","privilege_change","identity","identity_change",
                "firewall_config","firewall_change","ssh_config"
            } else
            "Medium" if category in {
                "service_change","systemd_config","network_config","network_change"
            } or category.startswith("exim_") else
            "Low"
        )

        events.append({
            "timestamp":event_time,
            "event_id":serial,
            "original_user":uid_name(auid) if auid not in ("","4294967295") else auid,
            "auid":auid,
            "run_as_user":uid_name(euid or uid) if (euid or uid) else "",
            "uid":uid,
            "euid":euid,
            "tty":tty,
            "session":ses,
            "path":chosen,
            "action":action,
            "command":command or comm,
            "comm":comm,
            "exe":exe,
            "cwd":cwd,
            "result":"SUCCESS" if success=="yes" else "FAILED",
            "category":category,
            "family":family,
            "risk":risk,
            "risk":"High",
            "raw":"\n".join(rows)
        })

    events.sort(key=lambda x:x["timestamp"],reverse=True)
    return events

# -----------------------------
# API
# -----------------------------
@app.get("/",response_class=HTMLResponse)
def index():
    return (BASE/"static/index.html").read_text(encoding="utf-8")

@app.get("/api/summary")
def summary(hours:int=Query(24,ge=1,le=720)):
    ev=ssh_events(hours); ses=current_sessions()
    auth=[e for e in ev if e["event_stage"] in ("Authentication success","Authentication failure","Invalid user")]
    byip=defaultdict(lambda:{"attempts":0,"success":0,"failures":0,"users":set()})
    byuser=defaultdict(lambda:{"success":0,"failures":0,"ips":set(),"last_seen":None})
    for e in auth:
        ip,u=e["source_ip"],e["username"]
        if ip:
            byip[ip]["attempts"]+=1; byip[ip]["success"]+=e["result"]=="SUCCESS"; byip[ip]["failures"]+=e["result"]=="FAILED"
            if u: byip[ip]["users"].add(u)
        if u:
            byuser[u]["success"]+=e["result"]=="SUCCESS"; byuser[u]["failures"]+=e["result"]=="FAILED"
            if ip: byuser[u]["ips"].add(ip)
            if not byuser[u]["last_seen"] or e["timestamp"]>byuser[u]["last_seen"]: byuser[u]["last_seen"]=e["timestamp"]
    return {"hours":hours,
      "kpis":{"active_sessions":len(ses),"successful_logins":sum(e["event_stage"]=="Authentication success" for e in ev),
              "failed_logins":sum(e["event_stage"]=="Authentication failure" for e in ev),"invalid_users":sum(e["event_stage"]=="Invalid user" for e in ev),
              "handshake_failures":sum(e["event_stage"]=="Handshake failure" for e in ev),
              "unique_source_ips":len({e["source_ip"] for e in ev if e["source_ip"]}),"critical_alerts":sum(e["risk"]=="Critical" for e in ev)},
      "events":ev[:300],"alerts":[e for e in ev if e["risk"] in ("High","Critical")][:25],
      "top_ips":[{"ip":ip,"attempts":v["attempts"],"success":v["success"],"failures":v["failures"],"users":sorted(v["users"])}
                 for ip,v in sorted(byip.items(),key=lambda x:x[1]["attempts"],reverse=True)][:20],
      "users":[{"user":u,"success":v["success"],"failures":v["failures"],"unique_ips":len(v["ips"]),"last_seen":v["last_seen"]} for u,v in byuser.items()],
      "sessions":ses}

@app.get("/api/sudo")
def sudo_api(hours:int=Query(24,ge=1,le=720)):
    ev=sudo_events(hours); byuser=defaultdict(int)
    for e in ev: byuser[e["username"]]+=1
    return {"hours":hours,
      "kpis":{"sudo_commands":len(ev),"unique_sudo_users":len(byuser),"run_as_root":sum(e["run_as"]=="root" for e in ev),
              "high_risk_commands":sum(e["risk"] in ("High","Critical") for e in ev)},
      "events":ev[:500],"top_users":[{"user":u,"commands":c} for u,c in sorted(byuser.items(),key=lambda x:x[1],reverse=True)]}

@app.get("/api/audit")
def audit_api(hours:int=Query(24,ge=1,le=720)):
    ev=audit_exim_events(hours)
    users=defaultdict(int); actions=defaultdict(int)
    for e in ev:
        users[e["original_user"]]+=1; actions[e["action"]]+=1
    return {"hours":hours,
      "kpis":{"audit_events":len(ev),"unique_change_users":len(users),"successful_changes":sum(e["result"]=="SUCCESS" for e in ev),
              "failed_changes":sum(e["result"]=="FAILED" for e in ev)},
      "events":ev[:500],
      "top_users":[{"user":u,"changes":c} for u,c in sorted(users.items(),key=lambda x:x[1],reverse=True)],
      "actions":[{"action":a,"count":c} for a,c in sorted(actions.items(),key=lambda x:x[1],reverse=True)]}
