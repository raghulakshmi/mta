# V9.0.9 Change Log

## Selected MTA persists across browser refresh

- The Server selector now remembers the operator's last choice in browser `localStorage`.
- If MTA1 is selected and the page is refreshed, the dashboard stays on MTA1 instead of reverting to MTA2.
- The selected-state border on the persistent MTA health cards follows the restored selection on the first refresh.

## Run Now

- Adds a **Run Now** button at the top-right immediately before the Server selector.
- Run Now requests an immediate collection cycle for the currently selected MTA instead of waiting for the normal 15-second collector interval.
- The dashboard backend signals the existing collector process with `SIGUSR1`; it does not start a second collector and does not restart either MTA or Exim.
- The collector reads the selected-MTA request from the shared dashboard data directory, collects that MTA, writes a fresh SQLite sample, and resumes its normal 15-second schedule.
- The API waits for the new sample before returning, so the UI refreshes only after fresh data has been written.
- Existing CPU/network delta state remains in the long-running collector process, avoiding the misleading zero-rate sample that a separate one-shot collector process would create.

## Carried forward from V9.0.8

- Delivery Legs — Last Minute: Delivered / Deferred / Failed for Proofpoint and Barracuda.
- Delivery-window per-leg outcomes.
- Persistent CPU, RAM, load and network header metrics.
- SQLite connection/file-descriptor leak fix.
- Sender + Recipient correlated Mail Search / Message Trace.
- Existing SQLite history preservation and timestamped code backups during upgrade.
