#!/usr/bin/env bash
set -euo pipefail
APP_DIR=/opt/mta-access-dashboard
SERVICE=mta-access-dashboard
[[ -d "$APP_DIR" ]] || { echo "ERROR: $APP_DIR not found. Install v1 first."; exit 1; }
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP="/opt/mta-access-dashboard-backup-$STAMP"
echo "Backing up current app to $BACKUP"
sudo cp -a "$APP_DIR" "$BACKUP"
sudo install -m 0644 app.py "$APP_DIR/app.py"
sudo mkdir -p "$APP_DIR/static"
sudo install -m 0644 static/index.html "$APP_DIR/static/index.html"
sudo systemctl restart "$SERVICE"
sudo systemctl --no-pager --full status "$SERVICE" || true
echo
echo "API validation:"
curl -fsS "http://127.0.0.1:8088/api/summary?hours=4" | head -c 1500
echo
echo
echo "Upgrade complete. Backup: $BACKUP"
