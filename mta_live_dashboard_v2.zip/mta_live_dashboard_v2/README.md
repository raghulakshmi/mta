# MTA Access Security Dashboard v2

This is an in-place upgrade for the v1 installation at `/opt/mta-access-dashboard`.

New telemetry:
- destination IP and port
- SSH key type
- SSH key fingerprint
- authorized_keys file and line
- sshd PID
- session child PID
- SSH handshake/pre-auth disconnects
- dedicated handshake-failure KPI
- click any activity row for full event detail and raw journal line

Upgrade:
```bash
chmod +x upgrade.sh
./upgrade.sh
```

The script backs up the current `/opt/mta-access-dashboard`, replaces only `app.py` and `static/index.html`, restarts the existing service, and validates the API.

Continue to access via:
```bash
ssh -L 8088:127.0.0.1:8088 ubuntu@<MTA_PUBLIC_IP>
```
then open `http://127.0.0.1:8088`.
