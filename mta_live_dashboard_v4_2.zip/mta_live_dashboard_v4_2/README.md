# v4.2

Fixes cross-tab refresh coupling.

SSH, Sudo, and Audit APIs are now fetched and rendered independently. A failure in Audit can no longer prevent the Sudo tab from rendering.

Top-right status now shows, for example:

`SSH:12 · Sudo:8 · Audit:2`

or explicitly `Sudo:ERR` / `Audit:ERR`.
