#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/mta-access-dashboard"
SERVICE="mta-access-dashboard"

[[ -d "$APP_DIR" ]] || { echo "ERROR: $APP_DIR not found."; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/opt/mta-access-dashboard-backup-$STAMP"

echo "Backing up current dashboard to $BACKUP"
sudo cp -a "$APP_DIR" "$BACKUP"

echo "Installing v4.2 frontend..."
sudo install -m 0644 app.py "$APP_DIR/app.py"
sudo install -m 0644 static/index.html "$APP_DIR/static/index.html"

echo "Restarting service..."
sudo systemctl restart "$SERVICE"

echo "Waiting for APIs..."
for i in {1..15}; do
  SSH_OK=0; SUDO_OK=0; AUDIT_OK=0
  curl -fsS "http://127.0.0.1:8088/api/summary?hours=4" >/tmp/mta-ssh.json 2>/dev/null && SSH_OK=1 || true
  curl -fsS "http://127.0.0.1:8088/api/sudo?hours=4" >/tmp/mta-sudo.json 2>/dev/null && SUDO_OK=1 || true
  curl -fsS "http://127.0.0.1:8088/api/audit?hours=4" >/tmp/mta-audit.json 2>/dev/null && AUDIT_OK=1 || true

  if [[ "$SSH_OK" -eq 1 && "$SUDO_OK" -eq 1 ]]; then
    echo "Core APIs ready after ${i}s. audit=$AUDIT_OK"
    break
  fi
  sleep 1
done

echo
echo "Endpoint check:"
python3 - <<'PY'
import json, os
for name,path in [('SSH','/tmp/mta-ssh.json'),('SUDO','/tmp/mta-sudo.json'),('AUDIT','/tmp/mta-audit.json')]:
    try:
        d=json.load(open(path))
        print(f"{name}: OK, events={len(d.get('events',[]))}")
    except Exception as e:
        print(f"{name}: ERROR: {e}")
PY

echo
echo "Verifying v4.2 frontend marker..."
grep -q "Sudo:ERR" "$APP_DIR/static/index.html" && echo "v4.2 renderer installed." || {
  echo "ERROR: v4.2 marker missing"
  exit 1
}

echo
echo "Upgrade complete."
echo "Backup: $BACKUP"
