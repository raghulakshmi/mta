# MTA Dashboard v4

Adds third tab: **Audit Changes**

Current audit scope:
- `key="exim_config"` only
- real filesystem changes under `/etc/exim4`
- excludes audit rule-add events

Shows:
- original logged-in user (`auid`)
- effective/run-as user
- TTY/session
- changed path
- CREATE / DELETE / CHANGE
- decoded command/proctitle
- executable and CWD in drill-down
- success/failure
- audit category

Upgrade:
```bash
chmod +x upgrade.sh
./upgrade.sh
```
Then hard refresh browser.
