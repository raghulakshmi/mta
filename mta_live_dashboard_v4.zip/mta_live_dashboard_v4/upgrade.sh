#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/mta-access-dashboard"
SERVICE="mta-access-dashboard"

[[ -d "$APP_DIR" ]] || { echo "ERROR: $APP_DIR not found."; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/opt/mta-access-dashboard-backup-$STAMP"

echo "Backing up current dashboard to $BACKUP"
sudo cp -a "$APP_DIR" "$BACKUP"

echo "Installing v4..."
sudo install -m 0644 app.py "$APP_DIR/app.py"
sudo mkdir -p "$APP_DIR/static"
sudo install -m 0644 static/index.html "$APP_DIR/static/index.html"

echo "Restarting service..."
sudo systemctl restart "$SERVICE"

echo "Waiting for all APIs..."
READY=0
for i in {1..15}; do
    if curl -fsS "http://127.0.0.1:8088/api/summary?hours=4" >/tmp/mta-ssh.json 2>/dev/null &&
       curl -fsS "http://127.0.0.1:8088/api/sudo?hours=4" >/tmp/mta-sudo.json 2>/dev/null &&
       curl -fsS "http://127.0.0.1:8088/api/audit?hours=4" >/tmp/mta-audit.json 2>/dev/null; then
        READY=1
        echo "All APIs ready after ${i}s."
        break
    fi
    sleep 1
done

if [[ "$READY" -ne 1 ]]; then
    echo "ERROR: Dashboard APIs did not become ready."
    sudo systemctl --no-pager --full status "$SERVICE" || true
    sudo journalctl -u "$SERVICE" -n 100 --no-pager || true
    exit 1
fi

echo
echo "Audit API sample:"
python3 -m json.tool </tmp/mta-audit.json | head -120

echo
echo "v4 upgrade completed successfully."
echo "Backup: $BACKUP"
echo "Hard refresh browser: Cmd+Shift+R / Ctrl+Shift+R"
