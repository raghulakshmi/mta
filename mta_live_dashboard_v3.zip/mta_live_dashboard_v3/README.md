# MTA Access Security Dashboard v3

Adds two primary tabs:

- SSH Access
- Sudo Activity

Sudo Activity shows:
- time
- user
- TTY
- working directory
- run-as user
- exact sudo command
- basic risk classification

Upgrade:
```bash
chmod +x upgrade.sh
./upgrade.sh
```

Then hard refresh the browser.
