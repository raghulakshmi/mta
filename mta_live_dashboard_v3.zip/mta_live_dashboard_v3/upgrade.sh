#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/mta-access-dashboard"
SERVICE="mta-access-dashboard"
TEST_URL="http://127.0.0.1:8088/api/summary?hours=4"
SUDO_TEST_URL="http://127.0.0.1:8088/api/sudo?hours=4"

[[ -d "$APP_DIR" ]] || { echo "ERROR: $APP_DIR not found."; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/opt/mta-access-dashboard-backup-$STAMP"

echo "Backing up current app to $BACKUP"
sudo cp -a "$APP_DIR" "$BACKUP"

echo "Installing v3 files..."
sudo install -m 0644 app.py "$APP_DIR/app.py"
sudo mkdir -p "$APP_DIR/static"
sudo install -m 0644 static/index.html "$APP_DIR/static/index.html"

echo "Restarting service..."
sudo systemctl restart "$SERVICE"

echo "Waiting for API..."
READY=0
for i in {1..15}; do
    if curl -fsS "$TEST_URL" >/tmp/mta-dashboard-test.json 2>/dev/null &&
       curl -fsS "$SUDO_TEST_URL" >/tmp/mta-dashboard-sudo-test.json 2>/dev/null; then
        READY=1
        echo "API ready after ${i}s."
        break
    fi
    sleep 1
done

if [[ "$READY" -ne 1 ]]; then
    echo "ERROR: Dashboard API did not become ready."
    sudo systemctl --no-pager --full status "$SERVICE" || true
    sudo journalctl -u "$SERVICE" -n 100 --no-pager || true
    exit 1
fi

echo
echo "Verifying sudo log readability..."
if [[ -r /var/log/sudo.log ]]; then
    echo "/var/log/sudo.log is readable by the dashboard service."
else
    echo "WARNING: /var/log/sudo.log is not readable. Current service runs as root in v1/v2, so check the service user if sudo data is blank."
fi

echo
echo "Upgrade v3 completed successfully."
echo "Backup: $BACKUP"
echo "Hard refresh browser: Cmd+Shift+R / Ctrl+Shift+R"
