# MTA Dashboard v5

Clean frontend rebuild.

No incremental JavaScript patching from earlier versions.

The Sudo tab:
- fetches `/api/sudo` independently
- shows a visible debug line: `Browser received N sudo event(s)`
- renders the exact API event list into `sudoRows`
- does not depend on SSH or Audit succeeding

Upgrade:
```bash
chmod +x upgrade.sh
./upgrade.sh
```

Then hard refresh the browser.
