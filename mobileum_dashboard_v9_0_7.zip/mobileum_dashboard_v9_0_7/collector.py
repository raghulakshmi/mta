#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import subprocess, json, time, re, signal, sys
from db import insert_sample, init_db, purge

BASE = Path(__file__).resolve().parent
CFG = json.loads((BASE / "config.json").read_text())
MTAS = list(CFG["mtas"].keys())
INTERVAL = int(CFG.get("collector_interval_seconds",15))
PP = CFG.get("proofpoint_router","proofpoint_copy")
BA = CFG.get("barracuda_router","barracuda_production")
SSH_OPTS = ["-o","BatchMode=yes","-o","ConnectTimeout=4","-o","ServerAliveInterval=4","-o","ServerAliveCountMax=1"]
RUN=True
PREV_METRICS={}

def stop(*_):
    global RUN
    RUN=False
signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)

def run_remote(mta, script, timeout=12):
    try:
        cp=subprocess.run(["ssh",*SSH_OPTS,mta,"sudo -n bash -s"], input=script, text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        if cp.returncode != 0:
            return "", (cp.stderr.strip() or f"ssh rc={cp.returncode}")[-400:]
        return cp.stdout, ""
    except Exception as e:
        return "", str(e)[:400]

def parse_age(s):
    m=re.fullmatch(r"(?:(\d+)d)?(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?",s or "")
    if not m: return 0
    d,h,mi,se=[int(x or 0) for x in m.groups()]
    return d*86400+h*3600+mi*60+se

def collect(mta):
    now=datetime.now(timezone.utc).isoformat()
    script=r'''set +e
EXIM=$(command -v exim4 || command -v exim)
MAIN=/var/log/exim4/mainlog
REJECT=/var/log/exim4/rejectlog
PANIC=/var/log/exim4/paniclog
SINCE=$(date -d '60 seconds ago' '+%Y-%m-%d %H:%M:%S' 2>/dev/null)
printf 'hostname=%s\n' "$(hostname -f 2>/dev/null || hostname)"
SAFE_UNIT=exim4-mobileum-safehold
SAFE_CFG=/etc/exim4/exim4.conf.mobileum-safehold
SAFE_STATE=$(systemctl is-active "$SAFE_UNIT" 2>/dev/null)
STD_STATE=$(systemctl is-active exim4 2>/dev/null)
if [ "$SAFE_STATE" = active ]; then
  SERVICE_STATE=active
  EXIM_CFG="-C $SAFE_CFG"
elif [ "$STD_STATE" = active ]; then
  SERVICE_STATE=active
  EXIM_CFG=""
else
  SERVICE_STATE=${SAFE_STATE:-$STD_STATE}
  [ -f "$SAFE_CFG" ] && EXIM_CFG="-C $SAFE_CFG" || EXIM_CFG=""
fi
printf 'service=%s\n' "${SERVICE_STATE:-inactive}"
printf 'listener=%s\n' "$(ss -ltnH 'sport = :25' 2>/dev/null | wc -l)"
printf 'connections=%s\n' "$(ss -Htn state established '( sport = :25 )' 2>/dev/null | wc -l)"
printf 'queue=%s\n' "$($EXIM $EXIM_CFG -bpc 2>/dev/null | tr -dc '0-9')"
Q="$($EXIM $EXIM_CFG -bp 2>/dev/null)"
printf 'frozen=%s\n' "$(printf '%s\n' "$Q" | grep -c '\*\*\* frozen \*\*\*')"
printf 'ages=%s\n' "$(printf '%s\n' "$Q" | awk '/^[[:space:]]*[0-9]+[smhd]/{print $1}' | tr '\n' ' ')"
TMPM=$(mktemp); TMPR=$(mktemp)
if [ -r "$MAIN" ] && [ -n "$SINCE" ]; then
 awk -v s="$SINCE" 'substr($0,1,19)>=s' "$MAIN" > "$TMPM"
 awk '/ <= /{c++} END{print "accepted=" c+0}' "$TMPM"
 awk '/ Completed$/{c++} END{print "completed=" c+0}' "$TMPM"
 awk '/ == /{c++} END{print "deferred=" c+0}' "$TMPM"
 awk '/ => / && /R=__PP__/{c++} END{print "proofpoint=" c+0}' "$TMPM"
 awk '/ => / && /R=__BA__/{c++} END{print "barracuda=" c+0}' "$TMPM"
 CONNC=$(grep 'SMTP connection from' "$TMPM" | grep -vE ' closed( |$)' | sed -n 's/.* Ci=\([^ ]*\).*/\1/p' | sort -u | wc -l)
 [ "$CONNC" -gt 0 ] || CONNC=$(grep 'SMTP connection from' "$TMPM" | grep -vcE ' closed( |$)')
 printf 'connection_starts=%s\n' "$CONNC"
 printf 'unique_sources=%s\n' "$(grep 'SMTP connection from' "$TMPM" | grep -vE ' closed( |$)' | sed -n 's/.*SMTP connection from[^[]*\[\([^]]*\)\].*/\1/p' | sort -u | wc -l)"
 printf 'connection_rejects=%s\n' "$(grep -Eic 'connection (rejected|refused)|too many connections|SMTP connection.*(rejected|dropped)' "$TMPM")"
 printf 'lost_connections=%s\n' "$(grep -Eic 'unexpectedly closed|lost incoming connection|Connection reset by peer|connection lost' "$TMPM")"
 printf 'no_mail=%s\n' "$(grep -Eic 'no MAIL' "$TMPM")"
 printf 'incomplete_tx=%s\n' "$(grep -Eic 'incomplete.*transaction|transaction.*incomplete' "$TMPM")"
 printf 'protocol_errors=%s\n' "$(grep -Eic 'SMTP protocol error|protocol error' "$TMPM")"
 printf 'syntax_errors=%s\n' "$(grep -Eic 'SMTP syntax error|syntax error' "$TMPM")"
 TLSC=$(grep ' X=' "$TMPM" | sed -n 's/.* Ci=\([^ ]*\).*/\1/p' | sort -u | wc -l)
 [ "$TLSC" -gt 0 ] || TLSC=$(grep -c ' X=' "$TMPM")
 printf 'tls_sessions=%s\n' "$TLSC"
else printf 'accepted=0\ncompleted=0\ndeferred=0\nproofpoint=0\nbarracuda=0\nconnection_starts=0\nunique_sources=0\nconnection_rejects=0\nlost_connections=0\nno_mail=0\nincomplete_tx=0\nprotocol_errors=0\nsyntax_errors=0\ntls_sessions=0\n'; fi
if [ -r "$REJECT" ] && [ -n "$SINCE" ]; then
 awk -v s="$SINCE" 'substr($0,1,19)>=s' "$REJECT" > "$TMPR"
 printf 'rejected=%s\n' "$(wc -l < "$TMPR")"
 printf 'relay_attempts=%s\n' "$(grep -Eic 'relay not permitted|relay.*denied|not permitted to relay' "$TMPR")"
 printf 'invalid_rcpt=%s\n' "$(grep -Eic 'invalid recipient|unknown recipient|unknown user|no such user|unrouteable address|recipient verify failed|recipient rejected' "$TMPR")"
else echo rejected=0; echo relay_attempts=0; echo invalid_rcpt=0; fi
rm -f "$TMPM" "$TMPR"
if [ -r "$PANIC" ] && [ -n "$SINCE" ]; then awk -v s="$SINCE" 'substr($0,1,19)>=s{c++} END{print "panic=" c+0}' "$PANIC"; else echo panic=0; fi
df -P /var/spool/exim4 2>/dev/null | awk 'NR==2{gsub("%","",$5); print "spool_used=" $5}'
df -Pi /var/spool/exim4 2>/dev/null | awk 'NR==2{gsub("%","",$5); print "spool_inode=" $5}'
# Host OS/resource counters. CPU and network rates are calculated by the
# Jumpbox collector from deltas between successive 15-second samples.
awk '/^cpu /{idle=$5+$6; total=0; for(i=2;i<=9;i++) total+=$i; printf "cpu_total=%.0f\ncpu_idle=%.0f\n", total, idle; exit}' /proc/stat 2>/dev/null
awk '/^MemTotal:/{t=$2}/^MemAvailable:/{a=$2}END{printf "mem_total_kb=%.0f\nmem_available_kb=%.0f\n",t+0,a+0}' /proc/meminfo 2>/dev/null
printf 'load1=%s\n' "$(awk '{print $1}' /proc/loadavg 2>/dev/null)"
IFACE=$(ip route show default 2>/dev/null | awk 'NR==1{print $5}')
printf 'net_iface=%s\n' "$IFACE"
if [ -n "$IFACE" ] && [ -r "/sys/class/net/$IFACE/statistics/rx_bytes" ]; then
  printf 'net_rx_bytes=%s\n' "$(cat /sys/class/net/$IFACE/statistics/rx_bytes)"
  printf 'net_tx_bytes=%s\n' "$(cat /sys/class/net/$IFACE/statistics/tx_bytes)"
else
  echo net_rx_bytes=0
  echo net_tx_bytes=0
fi
'''.replace('__PP__',PP).replace('__BA__',BA)
    out,err=run_remote(mta,script)
    if not out:
        return {"ts":now,"mta":mta,"reachable":0,"status":"UNREACHABLE","hostname":"","exim_service":"unknown","listener":0,
                "active_connections":0,"connection_starts_1m":0,"unique_sources_1m":0,"connection_rejects_1m":0,
                "lost_connections_1m":0,"no_mail_1m":0,"incomplete_tx_1m":0,"protocol_errors_1m":0,"syntax_errors_1m":0,
                "relay_attempts_1m":0,"invalid_rcpt_1m":0,"tls_sessions_1m":0,"queue_depth":0,"oldest_queue_seconds":0,"frozen":0,"accepted_1m":0,"rejected_1m":0,
                "completed_1m":0,"deferred_1m":0,"proofpoint_1m":0,"barracuda_1m":0,"tls_in_1m":0,"panic_1m":0,
                "spool_used_pct":0,"spool_inode_pct":0,"cpu_used_pct":0.0,"mem_used_pct":0.0,"load1":0.0,
                "net_iface":"","net_rx_mbps":0.0,"net_tx_mbps":0.0,"error":err or "no response"}
    d={}
    for line in out.splitlines():
        if "=" in line:
            k,v=line.split("=",1); d[k.strip()]=v.strip()
    def ni(k):
        try:return int(float(d.get(k,0) or 0))
        except:return 0
    # Current host utilization. CPU and network throughput are delta-based so
    # they represent the interval between collector samples, normally 15 sec.
    try: cpu_total=float(d.get("cpu_total",0) or 0)
    except: cpu_total=0.0
    try: cpu_idle=float(d.get("cpu_idle",0) or 0)
    except: cpu_idle=0.0
    try: mem_total=float(d.get("mem_total_kb",0) or 0)
    except: mem_total=0.0
    try: mem_avail=float(d.get("mem_available_kb",0) or 0)
    except: mem_avail=0.0
    try: load1=float(d.get("load1",0) or 0)
    except: load1=0.0
    try: rx_bytes=float(d.get("net_rx_bytes",0) or 0)
    except: rx_bytes=0.0
    try: tx_bytes=float(d.get("net_tx_bytes",0) or 0)
    except: tx_bytes=0.0
    sample_clock=time.monotonic()
    prev=PREV_METRICS.get(mta)
    cpu_used_pct=0.0; net_rx_mbps=0.0; net_tx_mbps=0.0
    if prev:
        dt=max(0.001, sample_clock-prev["clock"])
        total_delta=cpu_total-prev["cpu_total"]
        idle_delta=cpu_idle-prev["cpu_idle"]
        if total_delta>0 and idle_delta>=0:
            cpu_used_pct=max(0.0,min(100.0,100.0*(total_delta-idle_delta)/total_delta))
        if rx_bytes>=prev["rx_bytes"]:
            net_rx_mbps=(rx_bytes-prev["rx_bytes"])*8.0/dt/1_000_000.0
        if tx_bytes>=prev["tx_bytes"]:
            net_tx_mbps=(tx_bytes-prev["tx_bytes"])*8.0/dt/1_000_000.0
    PREV_METRICS[mta]={"clock":sample_clock,"cpu_total":cpu_total,"cpu_idle":cpu_idle,"rx_bytes":rx_bytes,"tx_bytes":tx_bytes}
    mem_used_pct=(100.0*(mem_total-mem_avail)/mem_total) if mem_total>0 else 0.0

    service=d.get("service","unknown")
    listener=ni("listener")>0
    status="UP" if service=="active" and listener else "DEGRADED"
    return {"ts":now,"mta":mta,"reachable":1,"status":status,"hostname":d.get("hostname",""),"exim_service":service,"listener":1 if listener else 0,
            "active_connections":ni("connections"),"connection_starts_1m":ni("connection_starts"),"unique_sources_1m":ni("unique_sources"),
            "connection_rejects_1m":ni("connection_rejects"),"lost_connections_1m":ni("lost_connections"),"no_mail_1m":ni("no_mail"),
            "incomplete_tx_1m":ni("incomplete_tx"),"protocol_errors_1m":ni("protocol_errors"),"syntax_errors_1m":ni("syntax_errors"),
            "relay_attempts_1m":ni("relay_attempts"),"invalid_rcpt_1m":ni("invalid_rcpt"),"tls_sessions_1m":ni("tls_sessions"),
            "queue_depth":ni("queue"),"oldest_queue_seconds":max([parse_age(x) for x in d.get("ages","").split()] or [0]),"frozen":ni("frozen"),
            "accepted_1m":ni("accepted"),"rejected_1m":ni("rejected"),"completed_1m":ni("completed"),"deferred_1m":ni("deferred"),
            "proofpoint_1m":ni("proofpoint"),"barracuda_1m":ni("barracuda"),"tls_in_1m":ni("tls_sessions"),"panic_1m":ni("panic"),
            "spool_used_pct":ni("spool_used"),"spool_inode_pct":ni("spool_inode"),
            "cpu_used_pct":round(cpu_used_pct,2),"mem_used_pct":round(mem_used_pct,2),"load1":round(load1,2),
            "net_iface":d.get("net_iface",""),"net_rx_mbps":round(net_rx_mbps,3),"net_tx_mbps":round(net_tx_mbps,3),"error":err}

def main():
    init_db(); n=0
    while RUN:
        start=time.monotonic()
        for mta in MTAS:
            try: insert_sample(collect(mta))
            except Exception as e: print(f"collector error {mta}: {e}", file=sys.stderr, flush=True)
        n+=1
        if n%240==0: purge(8)
        time.sleep(max(1, INTERVAL-(time.monotonic()-start)))

if __name__=="__main__": main()
