# V9.0.7 Change Log

## Persistent MTA health headers

- Adds current **CPU utilization**, **RAM utilization**, **1-minute load average**, and **network RX/TX throughput** to both MTA1 and MTA2 health cards.
- Both MTA cards continue to refresh independently every 5 seconds and remain visible regardless of the selected MTA in the server selector.
- Network throughput is the observed receive/transmit rate averaged over the collector interval (normally 15 seconds); it is not a percentage of EC2 link capacity.
- CPU utilization is calculated from `/proc/stat` deltas between collector samples.
- RAM utilization uses Linux `MemTotal` and `MemAvailable`.
- Network counters use the default-route interface and `/sys/class/net/<iface>/statistics/{rx_bytes,tx_bytes}`.
- Existing SQLite history is migrated in place with new columns; no database reset is required.

## Carried forward from V9.0.6

- SQLite connection/file-descriptor leak fix and FD regression verification.
- Sender + recipient correlated Mail Search / Message Trace.
- Existing history preservation and timestamped code backup during upgrade.
- FastAPI remains bound to `127.0.0.1:8089`; Nginx/public-access design is unchanged.
