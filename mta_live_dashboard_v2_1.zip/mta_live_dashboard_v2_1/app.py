
from fastapi import FastAPI, Query
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
import subprocess, re

app = FastAPI(title="MTA Access Security Dashboard v2")
BASE = Path(__file__).resolve().parent
app.mount("/static", StaticFiles(directory=BASE/"static"), name="static")

RX_CONN=re.compile(r"Connection from (?P<src_ip>\S+) port (?P<src_port>\d+) on (?P<dst_ip>\S+) port (?P<dst_port>\d+)")
RX_KEY=re.compile(r"Accepted key (?P<key_type>\S+) (?P<fingerprint>SHA256:\S+) found at (?P<auth_file>\S+):(?P<auth_line>\d+)")
RX_OK=re.compile(r"Accepted (?P<method>\S+) for (?P<user>\S+) from (?P<src_ip>\S+) port (?P<src_port>\d+) ssh2(?:: (?P<key_type>\S+) (?P<fingerprint>SHA256:\S+))?")
RX_FAIL=re.compile(r"Failed (?P<method>\S+) for (?:invalid user )?(?P<user>\S+) from (?P<src_ip>\S+) port (?P<src_port>\d+)")
RX_INVALID=re.compile(r"Invalid user (?P<user>\S+) from (?P<src_ip>\S+)")
RX_OPEN=re.compile(r"session opened for user (?P<user>\S+)\(uid=(?P<uid>\d+)\)")
RX_CHILD=re.compile(r"User child is on pid (?P<pid>\d+)")
RX_KEX=re.compile(r"kex_exchange_identification: Connection closed by remote host")

def run(cmd):
    try: return subprocess.check_output(cmd,text=True,stderr=subprocess.DEVNULL)
    except: return ""

def ts(line):
    try: return datetime.fromisoformat(line.split(" ",1)[0].replace("Z","+00:00")).isoformat()
    except: return datetime.now(timezone.utc).isoformat()

def blank(t):
    return dict(timestamp=t,event_stage="",username="",source_ip="",source_port="",destination_ip="",destination_port="",
                result="",method="",key_type="",key_fingerprint="",authorized_keys_file="",authorized_keys_line="",
                sshd_pid="",session_pid="",risk="Normal",raw="")

def events(hours):
    out=run(["journalctl","-u","ssh","--since",f"{hours} hours ago","--no-pager","-o","short-iso"])
    pending={}; ev=[]
    for line in out.splitlines():
        t=ts(line)
        pm=re.search(r"sshd\[(\d+)\]",line); pid=pm.group(1) if pm else ""
        c=pending.setdefault(pid,blank(t)); c["sshd_pid"]=pid
        m=RX_CONN.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Connection",source_ip=d["src_ip"],source_port=d["src_port"],
                destination_ip=d["dst_ip"],destination_port=d["dst_port"],result="CONNECTED",raw=line); ev.append(dict(c)); continue
        m=RX_KEY.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Key accepted",key_type=d["key_type"],key_fingerprint=d["fingerprint"],
                authorized_keys_file=d["auth_file"],authorized_keys_line=d["auth_line"],result="KEY_ACCEPTED",raw=line); ev.append(dict(c)); continue
        m=RX_OK.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Authentication success",username=d["user"],source_ip=d["src_ip"],
                source_port=d["src_port"],result="SUCCESS",method=d["method"],key_type=d.get("key_type") or c["key_type"],
                key_fingerprint=d.get("fingerprint") or c["key_fingerprint"],raw=line); ev.append(dict(c)); continue
        m=RX_FAIL.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Authentication failure",username=d["user"],source_ip=d["src_ip"],
                source_port=d["src_port"],result="FAILED",method=d["method"],risk="Medium",raw=line); ev.append(dict(c)); continue
        m=RX_INVALID.search(line)
        if m:
            d=m.groupdict(); c.update(timestamp=t,event_stage="Invalid user",username=d["user"],source_ip=d["src_ip"],
                result="FAILED",risk="High",raw=line); ev.append(dict(c)); continue
        m=RX_OPEN.search(line)
        if m:
            c.update(timestamp=t,event_stage="Session opened",username=m["user"],result="SESSION_OPEN",raw=line); ev.append(dict(c)); continue
        m=RX_CHILD.search(line)
        if m:
            c.update(timestamp=t,event_stage="Session child",session_pid=m["pid"],result="SESSION_ACTIVE",raw=line); ev.append(dict(c)); continue
        if RX_KEX.search(line):
            c.update(timestamp=t,event_stage="Handshake failure",result="PREAUTH_DISCONNECT",risk="Medium",raw=line); ev.append(dict(c)); continue
    fails=defaultdict(int)
    for e in ev:
        if e["result"]=="FAILED" and e["source_ip"]: fails[e["source_ip"]]+=1
    for e in ev:
        ip=e["source_ip"]
        if e["result"]=="FAILED" and ip and fails[ip]>=10: e["risk"]="High"
        if e["result"]=="SUCCESS" and ip and fails[ip]>=5: e["risk"]="Critical"
    ev.sort(key=lambda x:x["timestamp"],reverse=True)
    return ev

def sessions():
    s=[]
    for line in run(["who"]).splitlines():
        m=re.match(r"(?P<user>\S+)\s+(?P<tty>\S+)\s+(?P<date>\S+)\s+(?P<time>\S+)\s+\((?P<ip>[^)]+)\)",line)
        if m: s.append(m.groupdict())
    return s

@app.get("/",response_class=HTMLResponse)
def index(): return (BASE/"static/index.html").read_text()

@app.get("/api/summary")
def summary(hours:int=Query(24,ge=1,le=720)):
    ev=events(hours); ses=sessions()
    auth=[e for e in ev if e["event_stage"] in ("Authentication success","Authentication failure","Invalid user")]
    byip=defaultdict(lambda:{"attempts":0,"success":0,"failures":0,"users":set()})
    byuser=defaultdict(lambda:{"success":0,"failures":0,"ips":set(),"last_seen":None})
    for e in auth:
        ip,u=e["source_ip"],e["username"]
        if ip:
            byip[ip]["attempts"]+=1
            byip[ip]["success"]+= e["result"]=="SUCCESS"
            byip[ip]["failures"]+= e["result"]=="FAILED"
            if u: byip[ip]["users"].add(u)
        if u:
            byuser[u]["success"]+= e["result"]=="SUCCESS"
            byuser[u]["failures"]+= e["result"]=="FAILED"
            if ip: byuser[u]["ips"].add(ip)
            if not byuser[u]["last_seen"] or e["timestamp"]>byuser[u]["last_seen"]: byuser[u]["last_seen"]=e["timestamp"]
    return {
      "hours":hours,
      "kpis":{
        "active_sessions":len(ses),
        "successful_logins":sum(e["event_stage"]=="Authentication success" for e in ev),
        "failed_logins":sum(e["event_stage"]=="Authentication failure" for e in ev),
        "invalid_users":sum(e["event_stage"]=="Invalid user" for e in ev),
        "handshake_failures":sum(e["event_stage"]=="Handshake failure" for e in ev),
        "unique_source_ips":len({e["source_ip"] for e in ev if e["source_ip"]}),
        "critical_alerts":sum(e["risk"]=="Critical" for e in ev)
      },
      "events":ev[:300],
      "alerts":[e for e in ev if e["risk"] in ("High","Critical")][:25],
      "top_ips":[{"ip":ip,"attempts":v["attempts"],"success":v["success"],"failures":v["failures"],"users":sorted(v["users"])}
                 for ip,v in sorted(byip.items(),key=lambda x:x[1]["attempts"],reverse=True)][:20],
      "users":[{"user":u,"success":v["success"],"failures":v["failures"],"unique_ips":len(v["ips"]),"last_seen":v["last_seen"]}
               for u,v in byuser.items()],
      "sessions":ses
    }
