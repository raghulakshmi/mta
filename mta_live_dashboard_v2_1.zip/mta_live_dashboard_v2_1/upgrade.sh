#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/mta-access-dashboard"
SERVICE="mta-access-dashboard"
TEST_URL="http://127.0.0.1:8088/api/summary?hours=4"

[[ -d "$APP_DIR" ]] || { echo "ERROR: $APP_DIR not found."; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/opt/mta-access-dashboard-backup-$STAMP"

echo "Backing up current app to $BACKUP"
sudo cp -a "$APP_DIR" "$BACKUP"

echo "Applying v2.1 layout patch..."
if [[ -s app.py ]] && ! grep -q '^# keep existing' app.py; then
    sudo install -m 0644 app.py "$APP_DIR/app.py"
fi
sudo mkdir -p "$APP_DIR/static"
sudo install -m 0644 static/index.html "$APP_DIR/static/index.html"

echo "Restarting service..."
sudo systemctl restart "$SERVICE"

echo "Waiting for API..."
READY=0
for i in {1..15}; do
    if curl -fsS "$TEST_URL" >/tmp/mta-dashboard-test.json 2>/dev/null; then
        READY=1
        echo "API ready after ${i}s."
        break
    fi
    sleep 1
done

if [[ "$READY" -ne 1 ]]; then
    echo "ERROR: API did not become ready."
    sudo systemctl --no-pager --full status "$SERVICE" || true
    sudo journalctl -u "$SERVICE" -n 100 --no-pager || true
    exit 1
fi

echo "Verifying layout patch in deployed HTML..."
grep -o 'grid-template-columns:minmax(0,1fr) 360px' "$APP_DIR/static/index.html" || {
    echo "ERROR: layout patch not found in deployed HTML"
    exit 1
}

echo "Upgrade v2.1 completed successfully."
echo "Backup: $BACKUP"
echo "Browser: hard refresh with Ctrl+Shift+R / Cmd+Shift+R"
