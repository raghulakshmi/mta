# v2.1 Layout Patch

Fixes the narrowed Security Alerts panel.

The first row now uses:
`grid-template-columns:minmax(0,1fr) 360px`

The SSH activity table scrolls inside the left panel, while Security Alerts keeps a usable 360px width.

Run:
```bash
chmod +x upgrade.sh
./upgrade.sh
```

Then hard refresh the browser:
- macOS: Cmd+Shift+R
- Windows/Linux: Ctrl+Shift+R
